"""
Demo: a single customer session that crosses from the Billing agent to the
Tech agent, proving that memory persists across agents via DynamoDB.

Runs fully in MOCK_AWS mode (default) — no AWS account or running Kafka
broker required. Set publish_to_kafka=False here since no broker is running
in this demo; point it at docker/docker-compose.yml and flip to True to see
events flow across the real bus.

Usage:
    python scripts/demo.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.memory_store import MemoryStore
from src.orchestrator import Orchestrator


def main() -> None:
    memory = MemoryStore(table_name="demo-agent-memory")
    orchestrator = Orchestrator(memory_store=memory, publish_to_kafka=False)

    session_id = "demo-session-001"

    print("\n--- Turn 1: customer talks to Billing ---")
    result = orchestrator.process_message(session_id, "I was charged twice for my subscription this month")
    print(f"Routed to: {result['agent']}")
    print(f"Response:  {result['response']}")

    print("\n--- Turn 2: same session, now a tech issue ---")
    result = orchestrator.process_message(session_id, "Also, I can't log into my account anymore")
    print(f"Routed to: {result['agent']}")
    print(f"History used: {result['history_used']}  <- proves the Tech agent saw the Billing turn")
    print(f"Response:  {result['response']}")

    print("\n--- Full shared memory for this session ---")
    for event in memory.get_history(session_id):
        print(f"  [{event['agent']:8s}] {event['role']:6s}: {event['content']}")


if __name__ == "__main__":
    main()
