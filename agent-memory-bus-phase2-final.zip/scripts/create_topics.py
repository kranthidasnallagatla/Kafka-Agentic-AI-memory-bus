"""
Provisions the four Agent Memory Bus topics (agent.input, agent.memory,
agent.response, agent.audit), each with the partition/replication settings
from config.py. Safe to re-run — existing topics are skipped.

Usage:
    python scripts/create_topics.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from kafka.admin import KafkaAdminClient, NewTopic
from kafka.errors import TopicAlreadyExistsError

from src.config import config
from src.logger import get_logger

logger = get_logger("create_topics")


def main() -> None:
    admin = KafkaAdminClient(
        bootstrap_servers=config.kafka_bootstrap_servers,
        security_protocol=config.kafka_security_protocol,
    )

    topics = [
        NewTopic(
            name=topic,
            num_partitions=config.kafka_topic_partitions,
            replication_factor=config.kafka_topic_replication,
        )
        for topic in config.topics.all
    ]

    try:
        admin.create_topics(new_topics=topics, validate_only=False)
        logger.info(f"Created topics: {config.topics.all}")
    except TopicAlreadyExistsError:
        logger.info("One or more topics already exist — skipping those.")
    finally:
        admin.close()


if __name__ == "__main__":
    main()
