"""
DynamoDB-backed MemoryStore.

Table: agent-memory
  Partition key: session_id (S)
  Attributes:
    events        - list of event dicts (agent, role, content, timestamp)
    updated_at    - ISO8601 timestamp of last write
    agents_seen   - set of agent names that have touched this session

This is now the single source of truth for cross-agent memory (Phase 1's
in-memory MemoryStore has been retired). When config.mock_aws is True, all
calls run against an in-process moto mock so the module works identically
with zero AWS credentials; flipping MOCK_AWS=false in .env points it at a
real DynamoDB table/region with no code changes.
"""
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from .config import config
from .logger import get_logger

logger = get_logger("memory_store")

_moto_lock = threading.Lock()
_moto_ctx = None  # holds the active moto mock context for the process


def _start_moto_if_needed():
    """Start a process-wide moto mock_aws context exactly once."""
    global _moto_ctx
    if not config.mock_aws:
        return
    with _moto_lock:
        if _moto_ctx is None:
            from moto import mock_aws
            _moto_ctx = mock_aws()
            _moto_ctx.start()
            logger.info("moto mock_aws context started (MOCK_AWS=true, no real AWS calls will be made)")


class MemoryStore:
    """DynamoDB-backed shared memory for all agents on the bus."""

    def __init__(self, table_name: Optional[str] = None, region: Optional[str] = None):
        self.table_name = table_name or config.dynamodb_table_name
        self.region = region or config.dynamodb_region

        if config.mock_aws:
            _start_moto_if_needed()

        kwargs: Dict[str, Any] = {"region_name": self.region}
        if config.dynamodb_endpoint_url and not config.mock_aws:
            kwargs["endpoint_url"] = config.dynamodb_endpoint_url

        self._resource = boto3.resource("dynamodb", **kwargs)
        self._table = self._ensure_table()

    def _ensure_table(self):
        existing = [t.name for t in self._resource.tables.all()]
        if self.table_name in existing:
            return self._resource.Table(self.table_name)

        logger.info(f"Creating DynamoDB table '{self.table_name}'")
        table = self._resource.create_table(
            TableName=self.table_name,
            KeySchema=[{"AttributeName": "session_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "session_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        )
        table.wait_until_exists()
        return table

    def append_event(self, session_id: str, agent: str, role: str, content: str) -> Dict[str, Any]:
        """Append one memory event (a turn) to a session's history."""
        now = datetime.now(timezone.utc).isoformat()
        event = {"agent": agent, "role": role, "content": content, "timestamp": now}

        try:
            self._table.update_item(
                Key={"session_id": session_id},
                UpdateExpression=(
                    "SET events = list_append(if_not_exists(events, :empty), :e), "
                    "updated_at = :now "
                    "ADD agents_seen :agent_set"
                ),
                ExpressionAttributeValues={
                    ":e": [event],
                    ":empty": [],
                    ":now": now,
                    ":agent_set": {agent},
                },
            )
        except ClientError as exc:
            logger.error(f"Failed to append event for session={session_id}: {exc}")
            raise
        return event

    def get_history(self, session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Return the full (or last `limit`) event history for a session."""
        try:
            response = self._table.get_item(Key={"session_id": session_id})
        except ClientError as exc:
            logger.error(f"Failed to read session={session_id}: {exc}")
            raise
        item = response.get("Item")
        if not item:
            return []
        events = item.get("events", [])
        return list(events)[-limit:] if limit else list(events)

    def get_agents_seen(self, session_id: str) -> List[str]:
        try:
            response = self._table.get_item(Key={"session_id": session_id})
        except ClientError as exc:
            logger.error(f"Failed to read session={session_id}: {exc}")
            raise
        item = response.get("Item")
        if not item:
            return []
        return list(item.get("agents_seen", []))

    def clear_session(self, session_id: str) -> None:
        try:
            self._table.delete_item(Key={"session_id": session_id})
        except ClientError as exc:
            logger.error(f"Failed to clear session={session_id}: {exc}")
            raise

    def session_exists(self, session_id: str) -> bool:
        response = self._table.get_item(Key={"session_id": session_id})
        return "Item" in response
