"""Kafka consumer wrapper for the Agent Memory Bus topics."""
import json
from typing import Any, Callable, Dict, List, Optional

from kafka import KafkaConsumer as _KafkaConsumer

from .config import config
from .logger import get_logger

logger = get_logger("kafka_consumer")


class AgentBusConsumer:
    def __init__(
        self,
        topics: List[str],
        group_id: Optional[str] = None,
        bootstrap_servers: Optional[str] = None,
        auto_offset_reset: str = "earliest",
    ):
        self.topics = topics
        self.group_id = group_id or config.kafka_consumer_group
        self.bootstrap_servers = bootstrap_servers or config.kafka_bootstrap_servers

        kwargs: Dict[str, Any] = dict(
            bootstrap_servers=self.bootstrap_servers,
            group_id=self.group_id,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            key_deserializer=lambda k: k.decode("utf-8") if k else None,
            auto_offset_reset=auto_offset_reset,
            enable_auto_commit=True,
            security_protocol=config.kafka_security_protocol,
        )
        if config.kafka_sasl_mechanism:
            kwargs["sasl_mechanism"] = config.kafka_sasl_mechanism

        self._consumer = _KafkaConsumer(*topics, **kwargs)

    def poll_once(self, timeout_ms: int = 1000) -> List[Dict[str, Any]]:
        """Poll for available messages once and return their deserialized values."""
        records = self._consumer.poll(timeout_ms=timeout_ms)
        events = []
        for _, messages in records.items():
            for msg in messages:
                events.append(msg.value)
        return events

    def run(self, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Block and continuously dispatch each incoming event to `handler`."""
        logger.info(f"Consumer listening on topics={self.topics} group={self.group_id}")
        for message in self._consumer:
            handler(message.value)

    def close(self) -> None:
        self._consumer.close()
