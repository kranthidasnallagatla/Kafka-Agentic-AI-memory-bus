"""Routes an incoming message to the correct agent using Bedrock-based intent classification."""
from .bedrock_client import BedrockClient
from .logger import get_logger

logger = get_logger("intent_classifier")

INTENT_TO_AGENT = {
    "billing": "billing",
    "tech": "tech",
    "order": "order",
    "general": "tech",  # default fallback agent for unclassified messages
}


class IntentClassifier:
    def __init__(self, bedrock_client: BedrockClient = None):
        self._bedrock = bedrock_client or BedrockClient()

    def classify(self, message: str) -> str:
        """Returns the raw intent label (billing/tech/order/general)."""
        intent = self._bedrock.classify_intent(message)
        logger.info(f"Classified message as intent='{intent}'")
        return intent

    def route(self, message: str) -> str:
        """Returns the agent name that should handle this message."""
        intent = self.classify(message)
        return INTENT_TO_AGENT.get(intent, "tech")
