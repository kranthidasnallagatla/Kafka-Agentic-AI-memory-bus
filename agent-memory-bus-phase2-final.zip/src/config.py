"""
Central configuration for Agent Memory Bus.

All environment-driven settings live here so every module (Kafka, DynamoDB,
Bedrock, agents) reads from a single source of truth.
"""
import os
from dataclasses import dataclass, field
from typing import List

from dotenv import load_dotenv

load_dotenv()


def _get_bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class KafkaTopics:
    """The four topics that make up the Agent Memory Bus event backbone."""
    AGENT_INPUT: str = "agent.input"
    AGENT_MEMORY: str = "agent.memory"
    AGENT_RESPONSE: str = "agent.response"
    AGENT_AUDIT: str = "agent.audit"

    @property
    def all(self) -> List[str]:
        return [self.AGENT_INPUT, self.AGENT_MEMORY, self.AGENT_RESPONSE, self.AGENT_AUDIT]


@dataclass(frozen=True)
class Config:
    # --- Kafka / MSK ---
    kafka_bootstrap_servers: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    kafka_security_protocol: str = os.getenv("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT")  # SASL_SSL for MSK IAM
    kafka_sasl_mechanism: str = os.getenv("KAFKA_SASL_MECHANISM", "")  # AWS_MSK_IAM for MSK
    kafka_topic_partitions: int = int(os.getenv("KAFKA_TOPIC_PARTITIONS", "3"))
    kafka_topic_replication: int = int(os.getenv("KAFKA_TOPIC_REPLICATION", "1"))
    kafka_consumer_group: str = os.getenv("KAFKA_CONSUMER_GROUP", "agent-memory-bus")

    # --- DynamoDB ---
    dynamodb_table_name: str = os.getenv("DYNAMODB_TABLE_NAME", "agent-memory")
    dynamodb_region: str = os.getenv("AWS_REGION", "us-east-1")
    dynamodb_endpoint_url: str = os.getenv("DYNAMODB_ENDPOINT_URL", "")  # set for local/moto override

    # --- Bedrock ---
    bedrock_model_id: str = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")
    bedrock_region: str = os.getenv("AWS_REGION", "us-east-1")

    # --- Mock / stub mode ---
    # When True (default until real AWS creds are attached), Bedrock calls
    # return deterministic canned responses and DynamoDB runs against an
    # in-process moto mock instead of live AWS. Flip to False once credentials
    # and a real MSK/DynamoDB/Bedrock endpoint are wired up.
    mock_aws: bool = _get_bool("MOCK_AWS", True)

    topics: KafkaTopics = field(default_factory=KafkaTopics)


config = Config()
