"""
Orchestrator: the central coordinator of the Agent Memory Bus.

Flow for one incoming message:
  1. Consume from agent.input (or receive directly via process_message)
  2. Classify intent -> route to Billing / Tech / Order agent
  3. Agent reads shared memory (DynamoDB), generates a response via Bedrock,
     and writes the turn back to shared memory
  4. Publish an agent.memory event (mirrors the DynamoDB write onto the bus
     for downstream consumers/analytics)
  5. Publish the agent's reply to agent.response
  6. Publish an audit trail entry to agent.audit
"""
from typing import Any, Dict, Optional

from .agents import BillingAgent, OrderAgent, TechAgent
from .audit_logger import AuditLogger
from .bedrock_client import BedrockClient
from .config import config
from .intent_classifier import IntentClassifier
from .kafka_producer import AgentBusProducer
from .logger import get_logger
from .memory_store import MemoryStore

logger = get_logger("orchestrator")


class Orchestrator:
    def __init__(
        self,
        memory_store: Optional[MemoryStore] = None,
        producer: Optional[AgentBusProducer] = None,
        bedrock_client: Optional[BedrockClient] = None,
        publish_to_kafka: bool = True,
    ):
        self.memory = memory_store or MemoryStore()
        self.bedrock = bedrock_client or BedrockClient()
        self.classifier = IntentClassifier(self.bedrock)
        self.publish_to_kafka = publish_to_kafka

        self.producer = producer if producer is not None else (AgentBusProducer() if publish_to_kafka else None)
        self.audit = AuditLogger(self.producer) if self.publish_to_kafka else None

        self.agents = {
            "billing": BillingAgent(self.memory, self.bedrock),
            "tech": TechAgent(self.memory, self.bedrock),
            "order": OrderAgent(self.memory, self.bedrock),
        }

    def process_message(self, session_id: str, message: str) -> Dict[str, Any]:
        agent_name = self.classifier.route(message)
        agent = self.agents[agent_name]

        logger.info(f"session={session_id} routed to agent='{agent_name}'")

        result = agent.handle(session_id, message)

        if self.publish_to_kafka:
            self.producer.publish(
                config.topics.AGENT_MEMORY,
                {"session_id": session_id, "agent": agent_name, "message": message, "response": result["response"]},
                key=session_id,
            )
            self.producer.publish(
                config.topics.AGENT_RESPONSE,
                {"session_id": session_id, "agent": agent_name, "response": result["response"]},
                key=session_id,
            )
            self.audit.log(session_id, "message_handled", {"agent": agent_name, "message_length": len(message)})

        return result

    def close(self) -> None:
        if self.producer:
            self.producer.flush()
            self.producer.close()
