"""Publishes structured audit-trail events to the agent.audit topic."""
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .config import config
from .kafka_producer import AgentBusProducer
from .logger import get_logger

logger = get_logger("audit_logger")


class AuditLogger:
    def __init__(self, producer: Optional[AgentBusProducer] = None):
        self._producer = producer or AgentBusProducer()

    def log(self, session_id: str, event_type: str, details: Dict[str, Any]) -> bool:
        record = {
            "session_id": session_id,
            "event_type": event_type,
            "details": details,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        success = self._producer.publish(config.topics.AGENT_AUDIT, record, key=session_id)
        if not success:
            logger.warning(f"Audit event failed to publish: session={session_id} type={event_type}")
        return success
