"""
Kafka producer wrapper.

Publishes JSON-serialized events to the four Agent Memory Bus topics.
Configured for local Bitnami Kafka out of the box (PLAINTEXT on
localhost:9092); switching KAFKA_SECURITY_PROTOCOL/KAFKA_SASL_MECHANISM in
.env points the same code at an MSK cluster with IAM auth, no code changes.
"""
import json
from typing import Any, Dict, Optional

from kafka import KafkaProducer as _KafkaProducer
from kafka.errors import KafkaError

from .config import config
from .logger import get_logger

logger = get_logger("kafka_producer")


class AgentBusProducer:
    def __init__(self, bootstrap_servers: Optional[str] = None):
        self.bootstrap_servers = bootstrap_servers or config.kafka_bootstrap_servers
        self._producer = self._build_producer()

    def _build_producer(self) -> _KafkaProducer:
        kwargs: Dict[str, Any] = dict(
            bootstrap_servers=self.bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            security_protocol=config.kafka_security_protocol,
            retries=3,
            acks="all",
        )
        if config.kafka_sasl_mechanism:
            kwargs["sasl_mechanism"] = config.kafka_sasl_mechanism
        return _KafkaProducer(**kwargs)

    def publish(self, topic: str, event: Dict[str, Any], key: Optional[str] = None) -> bool:
        try:
            future = self._producer.send(topic, value=event, key=key)
            future.get(timeout=10)
            logger.info(f"Published event to topic='{topic}' key='{key}'")
            return True
        except KafkaError as exc:
            logger.error(f"Failed to publish to topic='{topic}': {exc}")
            return False

    def flush(self) -> None:
        self._producer.flush()

    def close(self) -> None:
        self._producer.close()
