"""
Bedrock client wrapper.

Wraps bedrock-runtime's InvokeModel call for Claude 3 Sonnet. When
config.mock_aws is True (default, no AWS account attached) this returns
deterministic canned completions via simple keyword heuristics instead of
making a network call, so the whole pipeline is runnable and testable with
zero AWS credentials. The public interface (`classify_intent`,
`generate_response`) is identical either way, so flipping MOCK_AWS=false
in .env and supplying real credentials is a drop-in swap to live Bedrock.
"""
import json
from typing import Dict

import boto3

from .config import config
from .logger import get_logger

logger = get_logger("bedrock_client")

VALID_INTENTS = ("billing", "tech", "order", "general")

_INTENT_KEYWORDS = {
    "billing": ("invoice", "charge", "refund", "payment", "bill", "subscription", "price", "credit card"),
    "tech": ("error", "bug", "crash", "not working", "broken", "install", "login", "password", "connect"),
    "order": ("order", "shipment", "shipping", "delivery", "tracking", "package", "return item", "cancel order"),
}


class BedrockClient:
    """Thin wrapper around bedrock-runtime InvokeModel with a mock fallback."""

    def __init__(self):
        self.mock = config.mock_aws
        if not self.mock:
            self._client = boto3.client("bedrock-runtime", region_name=config.bedrock_region)
        else:
            self._client = None
            logger.info("BedrockClient running in MOCK mode — no real Bedrock calls will be made")

    # ---------- public API ----------

    def classify_intent(self, message: str) -> str:
        if self.mock:
            return self._mock_classify(message)
        return self._live_classify(message)

    def generate_response(self, session_id: str, agent: str, message: str, history_summary: str = "") -> str:
        if self.mock:
            return self._mock_generate(agent, message, history_summary)
        return self._live_generate(agent, message, history_summary)

    # ---------- mock implementations ----------

    def _mock_classify(self, message: str) -> str:
        text = message.lower()
        scores: Dict[str, int] = {intent: 0 for intent in _INTENT_KEYWORDS}
        for intent, keywords in _INTENT_KEYWORDS.items():
            scores[intent] = sum(1 for kw in keywords if kw in text)
        best_intent, best_score = max(scores.items(), key=lambda kv: kv[1])
        return best_intent if best_score > 0 else "general"

    def _mock_generate(self, agent: str, message: str, history_summary: str) -> str:
        prefix = f"[{agent} agent]"
        continuity = f" Continuing from what we know: {history_summary}." if history_summary else ""
        return f"{prefix} Thanks for reaching out.{continuity} Regarding '{message.strip()}', here's how I can help: ..."

    # ---------- live Bedrock implementations ----------

    def _invoke(self, system_prompt: str, user_prompt: str, max_tokens: int = 300) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }
        response = self._client.invoke_model(
            modelId=config.bedrock_model_id,
            body=json.dumps(body),
        )
        payload = json.loads(response["body"].read())
        return payload["content"][0]["text"]

    def _live_classify(self, message: str) -> str:
        system_prompt = (
            "Classify the user's message into exactly one of: billing, tech, order, general. "
            "Respond with only the single lowercase word."
        )
        result = self._invoke(system_prompt, message, max_tokens=5).strip().lower()
        return result if result in VALID_INTENTS else "general"

    def _live_generate(self, agent: str, message: str, history_summary: str) -> str:
        system_prompt = (
            f"You are the {agent} support agent for a customer support platform. "
            f"Prior context for this session: {history_summary or 'none'}. "
            "Respond helpfully and concisely."
        )
        return self._invoke(system_prompt, message)
