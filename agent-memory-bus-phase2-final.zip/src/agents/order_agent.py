"""Order support agent: shipments, tracking, deliveries, returns."""
from .base_agent import BaseAgent


class OrderAgent(BaseAgent):
    name = "order"
