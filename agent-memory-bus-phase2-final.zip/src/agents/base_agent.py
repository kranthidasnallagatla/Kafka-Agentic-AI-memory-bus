"""Base class for all specialized support agents."""
from typing import Dict, List

from ..bedrock_client import BedrockClient
from ..memory_store import MemoryStore
from ..logger import get_logger


class BaseAgent:
    name: str = "base"

    def __init__(self, memory_store: MemoryStore, bedrock_client: BedrockClient = None):
        self.memory = memory_store
        self.bedrock = bedrock_client or BedrockClient()
        self.logger = get_logger(f"agent.{self.name}")

    def _summarize_history(self, session_id: str, max_events: int = 5) -> str:
        """Build a short text summary of recent cross-agent memory for this session."""
        history: List[Dict] = self.memory.get_history(session_id, limit=max_events)
        if not history:
            return ""
        parts = [f"{e['agent']}({e['role']}): {e['content']}" for e in history]
        return " | ".join(parts)

    def handle(self, session_id: str, message: str) -> Dict:
        """
        Handle an incoming message:
          1. Read cross-agent memory for context
          2. Record the user's message
          3. Generate a response via Bedrock
          4. Record the agent's response
          5. Return a structured result
        """
        history_summary = self._summarize_history(session_id)

        self.memory.append_event(session_id, agent=self.name, role="user", content=message)

        response_text = self.bedrock.generate_response(
            session_id=session_id, agent=self.name, message=message, history_summary=history_summary
        )

        self.memory.append_event(session_id, agent=self.name, role="agent", content=response_text)

        self.logger.info(f"session={session_id} handled message, response length={len(response_text)}")

        return {
            "session_id": session_id,
            "agent": self.name,
            "response": response_text,
            "history_used": bool(history_summary),
        }
