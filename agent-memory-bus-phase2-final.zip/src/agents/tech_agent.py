"""Tech support agent: errors, bugs, login/connectivity issues."""
from .base_agent import BaseAgent


class TechAgent(BaseAgent):
    name = "tech"
