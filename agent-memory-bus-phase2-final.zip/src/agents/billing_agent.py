"""Billing support agent: invoices, payments, refunds, subscriptions."""
from .base_agent import BaseAgent


class BillingAgent(BaseAgent):
    name = "billing"
