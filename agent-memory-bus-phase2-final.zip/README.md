# Agent Memory Bus — Phase 2 (Final)

A multi-agent AI customer support backend where specialized agents (Billing, Tech, Order) share persistent memory through a central Kafka event bus, eliminating context loss when a conversation crosses agent boundaries.

This is the **backend engine** — a chat UI is a planned, separate Phase 3 layer and is not part of this package.

## Architecture

```
Customer message
      │
      ▼
┌─────────────────┐      ┌─────────────────────┐
│ Intent Classifier │ --> │ Bedrock (Claude 3     │  (mocked by default,
│ (agent.input)      │     │ Sonnet) intent + reply│   see Mock Mode below)
└─────────────────┘      └─────────────────────┘
      │
      ▼ routes to
┌───────────┬───────────┬───────────┐
│  Billing   │   Tech     │  Order    │  Agents
└───────────┴───────────┴───────────┘
      │              read/write
      ▼
┌────────────────────────────┐
│ DynamoDB: agent-memory table │  partition key = session_id
└────────────────────────────┘
      │
      ▼ mirrors writes onto the bus
┌──────────────┬───────────────┬─────────────┐
│ agent.memory  │ agent.response │ agent.audit  │  Kafka topics
└──────────────┴───────────────┴─────────────┘
```

**The core guarantee:** if a customer starts with Billing and their next message is a Tech issue, the Tech agent reads the same DynamoDB session record and sees the full prior context — no repeating yourself, no lost context.

## Topics

| Topic | Purpose | Partitions |
|---|---|---|
| `agent.input` | Raw inbound customer messages | 3 |
| `agent.memory` | Mirror of every memory read/write | 3 |
| `agent.response` | Agent replies | 3 |
| `agent.audit` | Structured audit trail of every handled message | 3 |

## Mock mode (default)

`MOCK_AWS=true` (the default in `.env.example`) makes the entire pipeline runnable with **zero AWS credentials**:

- **DynamoDB** runs against an in-process [moto](https://github.com/getmoto/moto) mock — identical `boto3` API, no network calls.
- **Bedrock** returns deterministic canned intent classifications and responses via keyword heuristics — same method signatures as the live client.

Flip `MOCK_AWS=false` and supply real AWS credentials + region to point the exact same code at live DynamoDB and Bedrock. No application code changes required.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

### Run the demo (no Docker, no AWS needed)

```bash
python scripts/demo.py
```

### Run the test suite

```bash
pytest tests/ -v --cov=src --cov-report=term-missing
```

49 tests, 90% coverage, 100% on all agent and routing logic.

### Run against local Kafka (optional)

```bash
docker compose -f docker/docker-compose.yml up -d
python scripts/create_topics.py
```

Kafka UI is available at `http://localhost:8080` once the stack is up.

## Project layout

```
src/
  agents/              BillingAgent, TechAgent, OrderAgent (share BaseAgent)
  memory_store.py       DynamoDB-backed shared memory (session_id partition key)
  bedrock_client.py     Claude 3 Sonnet intent classification + response generation
  intent_classifier.py  Routes messages to the correct agent
  kafka_producer.py     Publishes to agent.memory / agent.response / agent.audit
  kafka_consumer.py     Consumes from agent.input
  audit_logger.py       Structured audit trail
  orchestrator.py       Wires all of the above into one request flow
  config.py             Single source of truth for all settings
tests/                  49 tests covering every module above
scripts/
  create_topics.py      Provisions the 4 Kafka topics
  demo.py                End-to-end cross-agent demo, no infra required
docker/
  docker-compose.yml    Bitnami Kafka + Zookeeper + Kafka UI
docs/                   Testing guide and technical report (Word format)
```

## Moving to production AWS

1. Set `MOCK_AWS=false` in `.env`.
2. Provide AWS credentials with `dynamodb:*` on the `agent-memory` table and `bedrock:InvokeModel` on the configured model.
3. Point `KAFKA_BOOTSTRAP_SERVERS` at your MSK cluster and set `KAFKA_SECURITY_PROTOCOL=SASL_SSL` / `KAFKA_SASL_MECHANISM=AWS_MSK_IAM`.
4. Re-run `scripts/create_topics.py` against the MSK cluster.

## Roadmap

- **Phase 3** (not started): React chat UI + API Gateway WebSocket layer.
- Exploring serverless Kafka (Upstash, WarpStream) and multi-tenant topic namespacing for a potential SaaS offering.
