from unittest.mock import MagicMock

from src.audit_logger import AuditLogger
from src.config import config


def test_log_publishes_to_audit_topic():
    mock_producer = MagicMock()
    mock_producer.publish.return_value = True

    audit = AuditLogger(mock_producer)
    result = audit.log("session-1", "message_handled", {"agent": "billing"})

    assert result is True
    args, kwargs = mock_producer.publish.call_args
    assert args[0] == config.topics.AGENT_AUDIT
    assert args[1]["session_id"] == "session-1"
    assert args[1]["event_type"] == "message_handled"
    assert args[1]["details"] == {"agent": "billing"}
    assert "timestamp" in args[1]
    assert kwargs["key"] == "session-1"


def test_log_returns_false_when_publish_fails():
    mock_producer = MagicMock()
    mock_producer.publish.return_value = False

    audit = AuditLogger(mock_producer)
    result = audit.log("session-2", "message_handled", {})

    assert result is False
