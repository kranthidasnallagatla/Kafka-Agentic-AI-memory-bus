from src.bedrock_client import BedrockClient, VALID_INTENTS


def test_mock_mode_enabled_by_default():
    client = BedrockClient()
    assert client.mock is True
    assert client._client is None


def test_classify_billing_intent():
    client = BedrockClient()
    intent = client.classify_intent("Why was I charged twice on my invoice?")
    assert intent == "billing"


def test_classify_tech_intent():
    client = BedrockClient()
    intent = client.classify_intent("I'm getting an error when I try to login")
    assert intent == "tech"


def test_classify_order_intent():
    client = BedrockClient()
    intent = client.classify_intent("Where is my package? I need shipment tracking")
    assert intent == "order"


def test_classify_general_intent_for_unrelated_message():
    client = BedrockClient()
    intent = client.classify_intent("Hello, how are you today?")
    assert intent == "general"


def test_classify_intent_always_valid():
    client = BedrockClient()
    for message in ["refund please", "app crashed", "cancel order", "hi there"]:
        assert client.classify_intent(message) in VALID_INTENTS


def test_generate_response_includes_agent_name():
    client = BedrockClient()
    response = client.generate_response("session-1", "billing", "I need a refund")
    assert "billing" in response.lower()


def test_generate_response_incorporates_history_summary():
    client = BedrockClient()
    response = client.generate_response(
        "session-1", "tech", "still broken", history_summary="billing(agent): refund issued"
    )
    assert "refund issued" in response
