import pytest

from src.agents import BillingAgent, OrderAgent, TechAgent
from src.memory_store import MemoryStore


@pytest.fixture
def memory():
    return MemoryStore(table_name="test-agents-memory")


def test_billing_agent_name(memory):
    agent = BillingAgent(memory)
    assert agent.name == "billing"


def test_tech_agent_name(memory):
    agent = TechAgent(memory)
    assert agent.name == "tech"


def test_order_agent_name(memory):
    agent = OrderAgent(memory)
    assert agent.name == "order"


def test_agent_handle_returns_structured_result(memory):
    agent = BillingAgent(memory)
    result = agent.handle("session-a", "Why was I double charged?")
    assert result["session_id"] == "session-a"
    assert result["agent"] == "billing"
    assert isinstance(result["response"], str) and len(result["response"]) > 0
    assert result["history_used"] is False  # first message, no prior history


def test_agent_handle_writes_two_events_to_memory(memory):
    agent = TechAgent(memory)
    agent.handle("session-b", "My login isn't working")
    history = memory.get_history("session-b")
    assert len(history) == 2
    assert history[0]["role"] == "user"
    assert history[1]["role"] == "agent"


def test_second_message_uses_history(memory):
    agent = OrderAgent(memory)
    agent.handle("session-c", "Where is my order?")
    result = agent.handle("session-c", "Still no update")
    assert result["history_used"] is True


def test_cross_agent_handoff_shares_memory(memory):
    """Billing agent's turn should be visible to the Tech agent on the same session."""
    billing = BillingAgent(memory)
    tech = TechAgent(memory)

    billing.handle("session-d", "I need a refund for my last invoice")
    result = tech.handle("session-d", "Also my account won't log in")

    assert result["history_used"] is True
    history = memory.get_history("session-d")
    agents_in_session = {e["agent"] for e in history}
    assert agents_in_session == {"billing", "tech"}


def test_summarize_history_empty_for_new_session(memory):
    agent = BillingAgent(memory)
    assert agent._summarize_history("brand-new-session") == ""


def test_summarize_history_respects_max_events(memory):
    agent = BillingAgent(memory)
    for i in range(10):
        memory.append_event("session-e", "billing", "user", f"msg {i}")
    summary = agent._summarize_history("session-e", max_events=3)
    assert summary.count("msg") == 3
