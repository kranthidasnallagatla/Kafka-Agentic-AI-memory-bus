import pytest

from src.memory_store import MemoryStore


@pytest.fixture
def store():
    return MemoryStore(table_name="test-agent-memory")


def test_table_created(store):
    assert store.table_name == "test-agent-memory"


def test_append_and_get_history(store):
    session_id = "session-1"
    store.append_event(session_id, agent="billing", role="user", content="Why was I charged twice?")
    history = store.get_history(session_id)
    assert len(history) == 1
    assert history[0]["agent"] == "billing"
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "Why was I charged twice?"
    assert "timestamp" in history[0]


def test_multiple_events_preserve_order(store):
    session_id = "session-2"
    store.append_event(session_id, "billing", "user", "First message")
    store.append_event(session_id, "billing", "agent", "First response")
    store.append_event(session_id, "tech", "user", "Second message")

    history = store.get_history(session_id)
    assert len(history) == 3
    assert [e["content"] for e in history] == ["First message", "First response", "Second message"]


def test_get_history_limit(store):
    session_id = "session-3"
    for i in range(5):
        store.append_event(session_id, "tech", "user", f"message {i}")
    history = store.get_history(session_id, limit=2)
    assert len(history) == 2
    assert history[-1]["content"] == "message 4"


def test_get_history_empty_session(store):
    assert store.get_history("nonexistent-session") == []


def test_agents_seen_tracks_unique_agents(store):
    session_id = "session-4"
    store.append_event(session_id, "billing", "user", "hi")
    store.append_event(session_id, "tech", "user", "hi again")
    store.append_event(session_id, "billing", "agent", "reply")

    agents = set(store.get_agents_seen(session_id))
    assert agents == {"billing", "tech"}


def test_session_exists(store):
    session_id = "session-5"
    assert store.session_exists(session_id) is False
    store.append_event(session_id, "order", "user", "Where's my package?")
    assert store.session_exists(session_id) is True


def test_clear_session(store):
    session_id = "session-6"
    store.append_event(session_id, "order", "user", "test")
    assert store.session_exists(session_id) is True
    store.clear_session(session_id)
    assert store.session_exists(session_id) is False
    assert store.get_history(session_id) == []


def test_cross_agent_shared_memory(store):
    """Core premise of the project: multiple agents share one session's memory."""
    session_id = "shared-session"
    store.append_event(session_id, "billing", "user", "I was charged twice")
    store.append_event(session_id, "billing", "agent", "I've issued a refund")
    store.append_event(session_id, "tech", "user", "Also my login is broken")

    history = store.get_history(session_id)
    agents_in_history = {e["agent"] for e in history}
    assert agents_in_history == {"billing", "tech"}
    assert len(history) == 3
