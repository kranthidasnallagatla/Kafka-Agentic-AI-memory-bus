from unittest.mock import MagicMock

import pytest

from src.memory_store import MemoryStore
from src.orchestrator import Orchestrator


@pytest.fixture
def memory():
    return MemoryStore(table_name="test-orchestrator-memory")


@pytest.fixture
def mock_producer():
    producer = MagicMock()
    producer.publish.return_value = True
    return producer


@pytest.fixture
def orchestrator(memory, mock_producer):
    return Orchestrator(memory_store=memory, producer=mock_producer, publish_to_kafka=True)


def test_billing_message_routed_correctly(orchestrator):
    result = orchestrator.process_message("s1", "Why does my invoice show a double charge?")
    assert result["agent"] == "billing"


def test_tech_message_routed_correctly(orchestrator):
    result = orchestrator.process_message("s2", "I can't log in, getting an error")
    assert result["agent"] == "tech"


def test_order_message_routed_correctly(orchestrator):
    result = orchestrator.process_message("s3", "Where is my shipment tracking number?")
    assert result["agent"] == "order"


def test_process_message_writes_to_shared_memory(orchestrator, memory):
    orchestrator.process_message("s4", "I need a refund")
    history = memory.get_history("s4")
    assert len(history) == 2
    assert history[0]["agent"] == "billing"


def test_process_message_publishes_memory_response_and_audit_events(orchestrator, mock_producer):
    orchestrator.process_message("s5", "My package never arrived")
    published_topics = [call.args[0] for call in mock_producer.publish.call_args_list]
    assert "agent.memory" in published_topics
    assert "agent.response" in published_topics
    assert "agent.audit" in published_topics


def test_multi_turn_conversation_across_agents_shares_context(orchestrator, memory):
    """End-to-end: billing handles turn 1, tech handles turn 2, both see the full session history."""
    orchestrator.process_message("s6", "I was charged twice, please refund me")
    result = orchestrator.process_message("s6", "Also my account login is broken now")

    assert result["agent"] == "tech"
    assert result["history_used"] is True

    history = memory.get_history("s6")
    agents_involved = {e["agent"] for e in history}
    assert agents_involved == {"billing", "tech"}
    assert len(history) == 4  # 2 turns x (user + agent) each


def test_orchestrator_without_kafka_publishing(memory):
    orch = Orchestrator(memory_store=memory, publish_to_kafka=False)
    result = orch.process_message("s7", "Cancel my order please")
    assert result["agent"] == "order"
    assert orch.producer is None
