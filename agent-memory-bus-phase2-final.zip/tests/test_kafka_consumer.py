from unittest.mock import MagicMock, patch

from src.kafka_consumer import AgentBusConsumer


@patch("src.kafka_consumer._KafkaConsumer")
def test_consumer_subscribes_to_given_topics(mock_kc):
    AgentBusConsumer(topics=["agent.input", "agent.memory"])
    args, _ = mock_kc.call_args
    assert "agent.input" in args
    assert "agent.memory" in args


@patch("src.kafka_consumer._KafkaConsumer")
def test_poll_once_returns_deserialized_values(mock_kc):
    mock_instance = MagicMock()
    mock_msg = MagicMock()
    mock_msg.value = {"session_id": "s1", "message": "hello"}
    mock_instance.poll.return_value = {"partition-0": [mock_msg]}
    mock_kc.return_value = mock_instance

    consumer = AgentBusConsumer(topics=["agent.input"])
    events = consumer.poll_once()

    assert events == [{"session_id": "s1", "message": "hello"}]


@patch("src.kafka_consumer._KafkaConsumer")
def test_poll_once_returns_empty_list_when_no_messages(mock_kc):
    mock_instance = MagicMock()
    mock_instance.poll.return_value = {}
    mock_kc.return_value = mock_instance

    consumer = AgentBusConsumer(topics=["agent.input"])
    assert consumer.poll_once() == []


@patch("src.kafka_consumer._KafkaConsumer")
def test_run_dispatches_each_message_to_handler(mock_kc):
    mock_instance = MagicMock()
    mock_msg1, mock_msg2 = MagicMock(), MagicMock()
    mock_msg1.value = {"n": 1}
    mock_msg2.value = {"n": 2}
    mock_instance.__iter__.return_value = iter([mock_msg1, mock_msg2])
    mock_kc.return_value = mock_instance

    consumer = AgentBusConsumer(topics=["agent.input"])
    seen = []
    consumer.run(seen.append)

    assert seen == [{"n": 1}, {"n": 2}]


@patch("src.kafka_consumer._KafkaConsumer")
def test_close_delegates_to_underlying_client(mock_kc):
    mock_instance = MagicMock()
    mock_kc.return_value = mock_instance

    consumer = AgentBusConsumer(topics=["agent.input"])
    consumer.close()

    mock_instance.close.assert_called_once()
