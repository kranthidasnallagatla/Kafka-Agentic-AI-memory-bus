from src.intent_classifier import IntentClassifier


def test_route_billing_message_to_billing_agent():
    classifier = IntentClassifier()
    assert classifier.route("I was charged twice for my subscription") == "billing"


def test_route_tech_message_to_tech_agent():
    classifier = IntentClassifier()
    assert classifier.route("The app keeps crashing on startup") == "tech"


def test_route_order_message_to_order_agent():
    classifier = IntentClassifier()
    assert classifier.route("I need tracking info for my shipment") == "order"


def test_route_general_message_falls_back_to_tech():
    classifier = IntentClassifier()
    assert classifier.route("Just saying hello!") == "tech"


def test_classify_returns_raw_intent_label():
    classifier = IntentClassifier()
    assert classifier.classify("Please issue a refund") == "billing"
