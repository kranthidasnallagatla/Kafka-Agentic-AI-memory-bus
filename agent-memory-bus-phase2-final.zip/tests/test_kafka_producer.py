from unittest.mock import MagicMock, patch

from src.kafka_producer import AgentBusProducer


@patch("src.kafka_producer._KafkaProducer")
def test_producer_builds_with_configured_bootstrap_servers(mock_kp):
    AgentBusProducer(bootstrap_servers="broker1:9092")
    _, kwargs = mock_kp.call_args
    assert kwargs["bootstrap_servers"] == "broker1:9092"


@patch("src.kafka_producer._KafkaProducer")
def test_publish_sends_and_waits_for_ack(mock_kp):
    mock_instance = MagicMock()
    mock_future = MagicMock()
    mock_instance.send.return_value = mock_future
    mock_kp.return_value = mock_instance

    producer = AgentBusProducer()
    result = producer.publish("agent.input", {"session_id": "s1", "message": "hi"}, key="s1")

    assert result is True
    mock_instance.send.assert_called_once()
    mock_future.get.assert_called_once()


@patch("src.kafka_producer._KafkaProducer")
def test_publish_returns_false_on_kafka_error(mock_kp):
    from kafka.errors import KafkaError

    mock_instance = MagicMock()
    mock_instance.send.side_effect = KafkaError("broker unavailable")
    mock_kp.return_value = mock_instance

    producer = AgentBusProducer()
    result = producer.publish("agent.input", {"session_id": "s1"}, key="s1")

    assert result is False


@patch("src.kafka_producer._KafkaProducer")
def test_flush_and_close_delegate_to_underlying_client(mock_kp):
    mock_instance = MagicMock()
    mock_kp.return_value = mock_instance

    producer = AgentBusProducer()
    producer.flush()
    producer.close()

    mock_instance.flush.assert_called_once()
    mock_instance.close.assert_called_once()
