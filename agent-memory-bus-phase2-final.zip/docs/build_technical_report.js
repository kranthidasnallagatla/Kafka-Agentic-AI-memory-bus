const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, LevelFormat,
} = require("docx");

const PAGE = { width: 12240, height: 15840 }; // US Letter

const h1 = (text) => new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 300, after: 150 } });
const h2 = (text) => new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 } });
const p = (text, opts = {}) => new Paragraph({ children: [new TextRun({ text, ...opts })], spacing: { after: 120 } });
const bullet = (text) => new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 60 } });
const rule = () => new Paragraph({ text: "", border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "CCCCCC" } }, spacing: { after: 200 } });

function cell(text, { header = false, width } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: header ? { type: ShadingType.CLEAR, fill: "2F5496" } : undefined,
    children: [new Paragraph({ children: [new TextRun({ text, bold: header, color: header ? "FFFFFF" : "000000" })] })],
  });
}

function table(headers, rows, widths) {
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({ children: headers.map((hh, i) => cell(hh, { header: true, width: widths[i] })) }),
      ...rows.map((r) => new TableRow({ children: r.map((c, i) => cell(c, { width: widths[i] })) })),
    ],
  });
}

const doc = new Document({
  sections: [
    {
      properties: { page: { size: PAGE } },
      children: [
        new Paragraph({ text: "Agent Memory Bus", heading: HeadingLevel.TITLE, spacing: { after: 60 } }),
        new Paragraph({
          children: [new TextRun({ text: "Phase 2 (Final) — Technical Report", bold: true, size: 28, color: "2F5496" })],
          spacing: { after: 40 },
        }),
        p("Multi-agent AI customer support backend with a shared, persistent memory bus", { italics: true, color: "555555" }),
        rule(),

        h1("1. Purpose & Scope"),
        p(
          "Agent Memory Bus is a backend engine for multi-agent customer support. Three specialized agents " +
          "— Billing, Tech, and Order — share one persistent memory store per customer session, so a conversation " +
          "that starts with one agent and continues with another retains full context instead of forcing the " +
          "customer to repeat themselves. This document covers the Phase 2 (Final) build: AWS-integrated intent " +
          "classification and response generation via Bedrock, DynamoDB-backed shared memory, and an MSK-compatible " +
          "Kafka event backbone. The React chat UI and API Gateway WebSocket layer are scoped to Phase 3 and are " +
          "not part of this package."
        ),

        h1("2. Architecture Overview"),
        p("The system is organized into five cooperating layers:"),
        bullet("Intent Classifier — routes an inbound message to Billing, Tech, or Order using Bedrock (Claude 3 Sonnet)"),
        bullet("Agents — BillingAgent, TechAgent, OrderAgent, all sharing one BaseAgent request-handling flow"),
        bullet("Memory Store — DynamoDB table agent-memory, partition key session_id, holds the full cross-agent event history"),
        bullet("Kafka Bus — four topics (agent.input, agent.memory, agent.response, agent.audit) mirror the flow of every message for downstream consumers, analytics, and audit"),
        bullet("Orchestrator — wires classification, agent handling, memory, and bus publication into one request flow"),

        h2("2.1 Request Flow"),
        p("For a single inbound customer message, the following sequence executes end-to-end:"),
        bullet("1. Orchestrator receives (session_id, message)"),
        bullet("2. IntentClassifier calls Bedrock to classify the message into billing / tech / order / general"),
        bullet("3. The message is routed to the corresponding agent instance"),
        bullet("4. The agent reads prior session history from DynamoDB to build context"),
        bullet("5. The agent writes the customer's message to DynamoDB, generates a reply via Bedrock, and writes the reply back to DynamoDB"),
        bullet("6. The orchestrator mirrors the turn onto agent.memory and agent.response, and logs an audit entry to agent.audit"),

        h1("3. Component Reference"),
        table(
          ["Module", "Responsibility"],
          [
            ["config.py", "Single source of truth for Kafka, DynamoDB, Bedrock, and mock-mode settings"],
            ["memory_store.py", "DynamoDB-backed MemoryStore — append_event, get_history, get_agents_seen, clear_session"],
            ["bedrock_client.py", "Wraps Bedrock InvokeModel for intent classification + response generation, with a mock mode"],
            ["intent_classifier.py", "Maps a classified intent to the agent responsible for handling it"],
            ["agents/base_agent.py", "Shared handle() flow: read history \u2192 write user turn \u2192 generate reply \u2192 write agent turn"],
            ["agents/billing_agent.py, tech_agent.py, order_agent.py", "Thin subclasses of BaseAgent, one per specialization"],
            ["kafka_producer.py / kafka_consumer.py", "MSK-compatible wrappers around kafka-python"],
            ["audit_logger.py", "Publishes structured audit trail entries to agent.audit"],
            ["orchestrator.py", "Coordinates the full request flow across all of the above"],
          ],
          [3600, 6300]
        ),

        h1("4. Data Model"),
        h2("4.1 DynamoDB — agent-memory table"),
        table(
          ["Attribute", "Type", "Description"],
          [
            ["session_id", "String (Partition Key)", "Unique identifier for one customer conversation"],
            ["events", "List", "Ordered list of {agent, role, content, timestamp} objects — the full cross-agent transcript"],
            ["agents_seen", "String Set", "Every agent name that has participated in this session"],
            ["updated_at", "String (ISO8601)", "Timestamp of the most recent write"],
          ],
          [2400, 2700, 4800]
        ),
        p("Billing mode is on-demand (PAY_PER_REQUEST) — appropriate for unpredictable, bursty support traffic without capacity planning overhead.", { italics: true, size: 20, color: "555555" }),

        h2("4.2 Kafka Topics"),
        table(
          ["Topic", "Purpose", "Partitions"],
          [
            ["agent.input", "Raw inbound customer messages", "3"],
            ["agent.memory", "Mirror of every memory read/write", "3"],
            ["agent.response", "Agent replies", "3"],
            ["agent.audit", "Structured audit trail of every handled message", "3"],
          ],
          [3000, 5400, 1500]
        ),

        h1("5. Mock Mode vs. Live AWS"),
        p(
          "The build defaults to MOCK_AWS=true, which lets the full pipeline run and be tested with zero AWS " +
          "credentials: DynamoDB calls run against an in-process moto mock (identical boto3 API surface), and " +
          "Bedrock calls return deterministic canned responses from keyword heuristics. Both mock paths use the " +
          "exact same public method signatures as their live counterparts (classify_intent, generate_response, " +
          "append_event, get_history), so switching MOCK_AWS=false and supplying real AWS credentials repoints " +
          "the same code at live DynamoDB and Bedrock with no application-code changes."
        ),
        table(
          ["Setting", "Mock mode (default)", "Live AWS"],
          [
            ["DynamoDB", "In-process moto mock_aws", "Real DynamoDB table via boto3"],
            ["Bedrock", "Keyword-heuristic canned responses", "Live InvokeModel call to Claude 3 Sonnet"],
            ["Kafka", "Local Bitnami broker (Docker Compose)", "MSK cluster, SASL_SSL / AWS_MSK_IAM"],
            ["Credentials required", "None", "AWS IAM credentials with DynamoDB + Bedrock + MSK permissions"],
          ],
          [2400, 3600, 3900]
        ),

        h1("6. Design Decisions & Rationale"),
        bullet("Single DynamoDB table, no local in-memory fallback: Phase 1's in-memory MemoryStore has been fully retired in favor of DynamoDB as the sole source of truth, removing the USE_LOCAL branching that existed mid-Phase 2."),
        bullet("session_id as sole partition key: keeps cross-agent lookups to a single get_item call and keeps the access pattern simple for the expected workload (one active record per conversation)."),
        bullet("Kafka topics mirror DynamoDB writes rather than replacing them: DynamoDB remains the durable, queryable source of truth; Kafka exists to let other services (analytics, notifications, a future Phase 3 UI) react to events in near-real-time without polling the table."),
        bullet("Mock-first design: every AWS-touching module is mock-capable by construction (not bolted on for tests), so the same code path is exercised in CI, local development, and production."),

        h1("7. Known Limitations & Phase 3 Scope"),
        bullet("No chat UI yet — Phase 3 (React + API Gateway WebSocket) will provide the customer-facing interface."),
        bullet("Intent classification in mock mode uses keyword heuristics, not a live LLM call — sufficient for development/testing, not representative of live Bedrock accuracy."),
        bullet("No multi-tenant namespacing yet — topics and the memory table are single-tenant; this is called out as a SaaS-commercialization consideration, not yet implemented."),

        h1("8. File Manifest"),
        p("See README.md in the project root for the full directory layout and setup instructions."),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => require("fs").writeFileSync("Agent_Memory_Bus_Phase2_Technical_Report.docx", buf));
