"""
config/settings.py
──────────────────
Central configuration for the Agent Memory Bus.
All values fall back to safe defaults for local development.
"""

import os
import logging
import colorlog
from dotenv import load_dotenv

load_dotenv()

# ── Kafka ──────────────────────────────────────────────────────────────────
KAFKA_BROKER   = os.getenv("KAFKA_BROKER", "localhost:9092")
KAFKA_GROUP_ID = os.getenv("KAFKA_GROUP_ID", "agent-memory-bus")

TOPICS = {
    "input":    "agent.input",
    "memory":   "agent.memory",
    "response": "agent.response",
    "audit":    "agent.audit",
}

# ── AWS (Phase 2) ──────────────────────────────────────────────────────────
AWS_REGION       = os.getenv("AWS_REGION", "us-east-1")
DYNAMODB_TABLE   = os.getenv("DYNAMODB_TABLE", "agent-memory")
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")

# ── Logging ────────────────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

def get_logger(name: str) -> logging.Logger:
    """Return a colour-formatted logger."""
    handler = colorlog.StreamHandler()
    handler.setFormatter(colorlog.ColoredFormatter(
        "%(log_color)s%(asctime)s [%(name)s] %(levelname)s%(reset)s — %(message)s",
        datefmt="%H:%M:%S",
        log_colors={
            "DEBUG":    "cyan",
            "INFO":     "green",
            "WARNING":  "yellow",
            "ERROR":    "red",
            "CRITICAL": "bold_red",
        },
    ))
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    if not logger.handlers:
        logger.addHandler(handler)
    return logger
