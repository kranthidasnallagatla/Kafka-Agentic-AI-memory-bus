# Agent Memory Bus

A **Kafka-powered multi-agent AI system** with shared persistent memory.

Traditional AI agents are stateless and siloed — each conversation starts fresh,
agents can't share context, and responses are inconsistent across sessions.

This system solves that by routing all agent communication through a **Kafka event bus**
and centralising state in a **shared memory layer** every agent reads and writes.
The result is coherent, context-aware responses across billing, tech, and order agents —
within and across conversations.

---

## Architecture

```
  ┌──────────────────────────────────────────────────────────────┐
  │                        CLIENT LAYER                          │
  │          Web / Mobile / REST API / Voice (Phase 2+)          │
  └─────────────────────────┬────────────────────────────────────┘
                            │
                   agent.input topic
                            │
  ┌─────────────────────────▼────────────────────────────────────┐
  │                      ORCHESTRATOR                            │
  │   Consumes agent.input → classifies intent → routes agent    │
  └──────┬──────────────────┬──────────────────┬─────────────────┘
         │                  │                  │
  ┌──────▼──────┐   ┌───────▼──────┐   ┌──────▼──────┐
  │  Billing    │   │    Tech      │   │   Order     │
  │   Agent     │   │   Agent      │   │   Agent     │
  └──────┬──────┘   └──────┬───────┘   └──────┬──────┘
         │                  │                  │
         └──────────────────┼──────────────────┘
                            │  writes
                  ┌─────────▼──────────┐
                  │   Shared Memory    │  ← MemoryStore
                  │  (DynamoDB Ph.2)   │    per session
                  └─────────┬──────────┘
                            │
              ┌─────────────┼──────────────┐
              │             │              │
      agent.response   agent.memory   agent.audit
              │
  ┌───────────▼──────────────────────────────────────────────────┐
  │                   RESPONSE CONSUMER                          │
  │              Displays agent replies in real time             │
  └──────────────────────────────────────────────────────────────┘
```

### Kafka Topics

| Topic            | Purpose                                        |
|------------------|------------------------------------------------|
| `agent.input`    | Inbound user messages → consumed by Orchestrator |
| `agent.memory`   | Memory read/write events (observability)       |
| `agent.response` | Agent replies → consumed by response consumer  |
| `agent.audit`    | Full audit trail of every agent action         |

---

## Quickstart (WSL2 / Linux / macOS)

### Prerequisites

- Docker Desktop with WSL2 backend (Windows) **or** Docker Engine (Linux/macOS)
- Python 3.9+

### 1 — Clone and setup

```bash
git clone https://github.com/YOUR_USERNAME/agent-memory-bus.git
cd agent-memory-bus

# One command does everything
bash scripts/setup.sh
```

This will:
- Install Python dependencies
- Create `.env` from `.env.example`
- Start Kafka + Zookeeper + Kafka UI via Docker
- Create all four Kafka topics

### 2 — Run the system (3 terminals)

**Terminal 1 — Orchestrator**
```bash
python agents/orchestrator.py
```

**Terminal 2 — Response stream**
```bash
python consumers/response_consumer.py
```

**Terminal 3 — Send messages**
```bash
# Built-in demo (8 messages across 3 agents)
python producers/input_producer.py --demo

# Interactive mode
python producers/input_producer.py

# Single message
python producers/input_producer.py --text "I need a refund" --user alice
```

### 3 — Kafka UI

Open [http://localhost:8080](http://localhost:8080) to inspect topics, messages, consumer groups, and lag in real time.

---

## Manual topic setup (if not using setup.sh)

```bash
cd docker
docker compose up -d
cd ..
bash scripts/create_topics.sh
```

---

## Project Structure

```
agent-memory-bus/
├── docker/
│   └── docker-compose.yml      # Kafka + Zookeeper + Kafka UI
├── config/
│   └── settings.py             # Central config, reads from .env
├── memory/
│   └── memory_store.py         # Thread-safe shared memory (Phase 2: DynamoDB)
├── agents/
│   ├── base_agent.py           # Abstract base — Kafka producer, memory helpers
│   ├── orchestrator.py         # Consumer + intent router
│   ├── billing_agent.py        # Invoices, charges, refunds, subscriptions
│   ├── tech_agent.py           # Errors, bugs, login, setup
│   └── order_agent.py          # Tracking, returns, cancellations
├── producers/
│   └── input_producer.py       # Publishes messages to agent.input
├── consumers/
│   └── response_consumer.py    # Reads agent.response / agent.audit
├── scripts/
│   ├── setup.sh                # One-shot environment setup
│   └── create_topics.sh        # Creates Kafka topics
├── tests/
│   ├── test_memory_store.py    # 10 unit tests — no Kafka needed
│   ├── test_agents.py          # 17 unit tests — no Kafka needed
│   └── test_producer.py        # 5 unit tests  — no Kafka needed
├── .env.example
├── .gitignore
└── requirements.txt
```

---

## Running Tests

No Kafka or Docker required for tests — producers and consumers are mocked.

```bash
# All tests
python -m pytest tests/ -v

# Individual suites
python tests/test_memory_store.py
python tests/test_agents.py
python tests/test_producer.py
```

---

## Watching the Audit Trail

```bash
python consumers/response_consumer.py --topic audit
```

Every agent action — routing decision, response generated, memory write — is
published to `agent.audit` with a full payload and timestamp.

---

## Phase Roadmap

| Phase | Status | Description |
|-------|--------|-------------|
| **1** | ✅ Complete | Local Kafka (Docker), in-memory state, keyword routing |
| **2** | 🔜 Planned | AWS MSK, DynamoDB shared memory, Bedrock LLM agents |
| **3** | 🔜 Planned | AWS API Gateway, multi-client interface (REST / voice) |
| **4** | 🔜 Planned | CloudWatch metrics, SNS alerts, S3 audit archival |

### Phase 2 upgrade path

Every Phase 2 hook is already stubbed in the code:

- **Memory** → swap `MemoryStore` for `DynamoMemoryStore` in `memory/memory_store.py`
- **Agents** → replace `_generate_response()` with a `bedrock_client.invoke_model()` call
- **Routing** → replace keyword classifier in `orchestrator.py` with a Bedrock zero-shot call
- **Kafka** → change `KAFKA_BROKER` in `.env` to your MSK endpoint

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `KAFKA_BROKER` | `localhost:9092` | Kafka bootstrap server |
| `KAFKA_GROUP_ID` | `agent-memory-bus` | Consumer group ID |
| `AWS_REGION` | `us-east-1` | AWS region (Phase 2) |
| `DYNAMODB_TABLE` | `agent-memory` | DynamoDB table name (Phase 2) |
| `BEDROCK_MODEL_ID` | `anthropic.claude-3-sonnet-...` | Bedrock model (Phase 2) |
| `LOG_LEVEL` | `INFO` | Python log level |

---

## License

Private — all rights reserved.
