"""
agents/orchestrator.py
──────────────────────
The Orchestrator is the brain of the Agent Memory Bus.

Responsibilities:
  1. Consume messages from `agent.input`
  2. Classify intent → route to the correct sub-agent
  3. Sub-agent processes via shared MemoryStore and publishes to `agent.response`
  4. Publish routing decision to `agent.audit`

Phase 1 → keyword-based intent classifier
Phase 2 → replace _classify_intent() with Bedrock LLM call for zero-shot routing
"""

import json
import signal
import sys

from kafka import KafkaConsumer
from kafka.errors import KafkaError

from config.settings import KAFKA_BROKER, KAFKA_GROUP_ID, TOPICS, get_logger
from memory.memory_store import MemoryStore
from agents.billing_agent import BillingAgent
from agents.tech_agent import TechAgent
from agents.order_agent import OrderAgent


logger = get_logger("Orchestrator")


# ── Intent → keywords mapping ──────────────────────────────────────────────
INTENT_KEYWORDS = {
    "billing": [
        "invoice", "charge", "refund", "subscription", "payment",
        "billing", "discount", "overcharge", "credit card", "receipt",
        "cost", "price", "fee", "account balance",
    ],
    "tech": [
        "error", "crash", "slow", "login", "password", "install",
        "bug", "update", "api", "connectivity", "setup", "not working",
        "broken", "issue", "problem", "help me fix", "exception",
    ],
    "order": [
        "order", "track", "cancel", "return", "refund", "shipping",
        "delay", "deliver", "exchange", "missing", "package", "parcel",
        "dispatch", "receipt", "courier",
    ],
}


class Orchestrator:

    def __init__(self):
        self.memory  = MemoryStore()
        self.agents  = {
            "billing": BillingAgent(self.memory),
            "tech":    TechAgent(self.memory),
            "order":   OrderAgent(self.memory),
        }
        self.consumer = self._build_consumer()
        self._running = False
        logger.info("Orchestrator ready — agents: billing, tech, order")

    # ── Main loop ──────────────────────────────────────────────────────────

    def run(self) -> None:
        self._running = True
        self._register_shutdown()
        logger.info(f"Listening on topic: {TOPICS['input']} ...")

        try:
            for kafka_message in self.consumer:
                if not self._running:
                    break
                self._handle_kafka_message(kafka_message)
        except Exception as e:
            logger.error(f"Consumer loop error: {e}")
        finally:
            self.consumer.close()
            logger.info("Orchestrator shut down cleanly.")

    # ── Internal ───────────────────────────────────────────────────────────

    def _handle_kafka_message(self, kafka_message) -> None:
        try:
            raw   = kafka_message.value.decode("utf-8")
            msg   = json.loads(raw)
            logger.info(
                f"[{msg.get('session_id', '?')}] ← received: \"{msg.get('text', '')[:60]}\""
            )
        except (json.JSONDecodeError, AttributeError) as e:
            logger.error(f"Failed to decode message: {e}")
            return

        session_id = msg.get("session_id")
        text       = msg.get("text", "")

        if not session_id or not text:
            logger.warning("Message missing session_id or text — skipping.")
            return

        intent = self._classify_intent(text)
        logger.info(f"[{session_id}] intent → {intent}")

        agent = self.agents.get(intent)
        if not agent:
            logger.error(f"No agent registered for intent: {intent}")
            return

        # Delegate to the chosen agent (publish to agent.response internally)
        agent.process(msg)

    def _classify_intent(self, text: str) -> str:
        """
        Phase 1: keyword voting across intent buckets.

        Phase 2 — Bedrock zero-shot classifier:
            response = bedrock_client.invoke_model(
                modelId=BEDROCK_MODEL_ID,
                body=json.dumps({
                    "prompt": CLASSIFY_PROMPT.format(text=text),
                    "max_tokens": 10,
                })
            )
            label = parse_label(response)  # "billing" | "tech" | "order"
            return label
        """
        text_lower = text.lower()
        scores     = {intent: 0 for intent in INTENT_KEYWORDS}

        for intent, keywords in INTENT_KEYWORDS.items():
            for kw in keywords:
                if kw in text_lower:
                    scores[intent] += 1

        best = max(scores, key=scores.get)
        # If no keywords matched at all, fall back to tech (safest generic)
        return best if scores[best] > 0 else "tech"

    def _build_consumer(self) -> KafkaConsumer:
        return KafkaConsumer(
            TOPICS["input"],
            bootstrap_servers=KAFKA_BROKER,
            group_id=KAFKA_GROUP_ID,
            auto_offset_reset="latest",
            enable_auto_commit=True,
            value_deserializer=None,   # raw bytes — we decode in _handle_kafka_message
        )

    def _register_shutdown(self) -> None:
        def _handler(sig, frame):
            logger.info("Shutdown signal received.")
            self._running = False

        signal.signal(signal.SIGINT, _handler)
        signal.signal(signal.SIGTERM, _handler)


# ── Entry point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    Orchestrator().run()
