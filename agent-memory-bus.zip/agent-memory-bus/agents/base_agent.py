"""
agents/base_agent.py
────────────────────
Abstract base class every agent inherits from.
Provides shared Kafka producer, memory access, and event publishing helpers.
"""

import json
from abc import ABC, abstractmethod
from datetime import datetime

from kafka import KafkaProducer
from kafka.errors import KafkaError

from config.settings import KAFKA_BROKER, TOPICS, get_logger
from memory.memory_store import MemoryStore


class BaseAgent(ABC):

    def __init__(self, agent_id: str, memory_store: MemoryStore):
        self.agent_id     = agent_id
        self.memory       = memory_store
        self.logger       = get_logger(agent_id)
        self._producer    = self._build_producer()

    # ── Must implement ─────────────────────────────────────────────────────

    @abstractmethod
    def handle(self, message: dict) -> str:
        """
        Process an inbound message dict and return a plain-text response.

        message schema:
        {
            "session_id": str,
            "user_id":    str,
            "text":       str,   # the user's raw input
            "metadata":   dict,  # optional extras
        }
        """

    # ── Helpers ────────────────────────────────────────────────────────────

    def process(self, message: dict) -> None:
        """
        Full pipeline: handle → publish response → audit.
        Called by the Orchestrator.
        """
        session_id = message["session_id"]
        user_id    = message["user_id"]
        text       = message.get("text", "")

        # Log to shared memory
        self.memory.append_history(session_id, "user", text)
        self.memory.set_last_agent(session_id, self.agent_id)

        # Agent-specific logic
        response_text = self.handle(message)

        # Store response in history
        self.memory.append_history(session_id, "assistant", response_text)

        # Publish to agent.response
        self._publish_response(session_id, user_id, response_text)

        # Publish to agent.audit
        self._publish_audit(session_id, "RESPONSE_GENERATED", {
            "user_text": text,
            "response":  response_text,
        })

        self.logger.info(f"[{session_id}] handled and published ✓")

    def get_history(self, session_id: str) -> list:
        return self.memory.get_history(session_id)

    def get_context(self, session_id: str, key: str, default=None):
        return self.memory.get_context(session_id, key, default)

    def set_context(self, session_id: str, key: str, value) -> None:
        self.memory.update(session_id, key, value)

    # ── Private ────────────────────────────────────────────────────────────

    def _publish_response(self, session_id: str, user_id: str, response_text: str) -> None:
        event = {
            "session_id": session_id,
            "user_id":    user_id,
            "agent_id":   self.agent_id,
            "response":   response_text,
            "timestamp":  _now(),
        }
        self._safe_send(TOPICS["response"], session_id, event)

    def _publish_audit(self, session_id: str, event_type: str, payload: dict) -> None:
        event = {
            "session_id": session_id,
            "agent_id":   self.agent_id,
            "event_type": event_type,
            "payload":    payload,
            "timestamp":  _now(),
        }
        self._safe_send(TOPICS["audit"], session_id, event)

    def _safe_send(self, topic: str, key: str, value: dict) -> None:
        try:
            future = self._producer.send(
                topic,
                key=key.encode("utf-8"),
                value=json.dumps(value).encode("utf-8"),
            )
            self._producer.flush()
            future.get(timeout=10)
        except KafkaError as e:
            self.logger.error(f"Kafka send failed on topic={topic}: {e}")

    def _build_producer(self) -> KafkaProducer:
        return KafkaProducer(
            bootstrap_servers=KAFKA_BROKER,
            retries=5,
            acks="all",
            linger_ms=5,
        )


def _now() -> str:
    return datetime.utcnow().isoformat()
