"""
agents/billing_agent.py
───────────────────────
Handles billing, payment, invoice, and subscription queries.

Phase 1 → rule-based responses + shared memory awareness
Phase 2 → replace _generate_response() with AWS Bedrock call
"""

from agents.base_agent import BaseAgent
from memory.memory_store import MemoryStore


class BillingAgent(BaseAgent):

    KEYWORDS = {
        "invoice":      "I can pull up your invoice history. Please provide your account ID "
                        "or the invoice number and I'll retrieve the details right away.",
        "charge":       "I see you have a question about a charge. I'll review your recent "
                        "transactions and dispute any unauthorised amounts on your behalf.",
        "refund":       "Refunds are typically processed within 5–7 business days. I'll "
                        "initiate the refund request now and send you a confirmation email.",
        "subscription": "I can help you upgrade, downgrade, or cancel your subscription. "
                        "Which plan would you like to switch to?",
        "payment":      "Your payment information is encrypted and secure. Would you like "
                        "to update your payment method or review recent transactions?",
        "billing":      "I'm your Billing Agent. I can help with invoices, charges, "
                        "refunds, and subscription management. What do you need?",
        "discount":     "I've checked your account and you qualify for a loyalty discount. "
                        "I'll apply a 10% credit to your next invoice.",
        "overcharge":   "I sincerely apologise for the overcharge. I'll escalate this "
                        "immediately and ensure a full refund within 3 business days.",
    }

    DEFAULT_RESPONSE = (
        "I'm your Billing Agent. I can assist with invoices, charges, refunds, "
        "subscriptions, and payment methods. Could you provide more details about your issue?"
    )

    def __init__(self, memory_store: MemoryStore):
        super().__init__("BillingAgent", memory_store)

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "").lower()

        # Use shared memory context to personalise response
        visit_count = self.get_context(session_id, "billing_visits", 0) + 1
        self.set_context(session_id, "billing_visits", visit_count)

        response = self._generate_response(text)

        if visit_count > 1:
            response = f"Welcome back! {response}"

        self.logger.info(f"[{session_id}] BillingAgent responded (visit #{visit_count})")
        return response

    def _generate_response(self, text: str) -> str:
        """
        Phase 1: keyword matching.
        Phase 2: replace with Bedrock call →
            import boto3
            client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
            response = client.invoke_model(
                modelId=BEDROCK_MODEL_ID,
                body=json.dumps({"prompt": text, "max_tokens": 512})
            )
            return json.loads(response["body"].read())["completion"]
        """
        for keyword, reply in self.KEYWORDS.items():
            if keyword in text:
                return reply
        return self.DEFAULT_RESPONSE
