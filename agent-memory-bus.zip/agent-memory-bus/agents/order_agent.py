"""
agents/order_agent.py
─────────────────────
Handles order tracking, returns, cancellations, and shipping queries.

Phase 1 → rule-based responses + shared memory (tracks order history)
Phase 2 → replace _generate_response() with AWS Bedrock call
"""

import random
import string
from agents.base_agent import BaseAgent
from memory.memory_store import MemoryStore


class OrderAgent(BaseAgent):

    KEYWORDS = {
        "track":    "Your order is currently in transit. Expected delivery: "
                    "{eta}. Tracking number: {tracking}.",
        "cancel":   "I've initiated the cancellation for your order. You'll receive "
                    "a confirmation email within 10 minutes and a full refund in 5–7 days.",
        "return":   "I've created a return label (valid 30 days). You'll receive it "
                    "by email. Drop the package at any authorised courier location.",
        "refund":   "Your refund of ${amount} has been approved and will appear on "
                    "your statement within 5–7 business days.",
        "shipping": "We offer Standard (5–7 days), Express (2–3 days), and "
                    "Overnight shipping. Which would you prefer?",
        "delay":    "I sincerely apologise for the delay. I've flagged your order "
                    "to our logistics team and applied a $10 credit to your account.",
        "order":    "I can help with order placement, tracking, modifications, "
                    "and returns. What is your order number?",
        "deliver":  "Your order is out for delivery today and should arrive by 8 PM. "
                    "You'll receive an SMS when it's at your door.",
        "exchange": "I've initiated an exchange for your item. The replacement will "
                    "ship within 2 business days once we receive the original.",
        "missing":  "I'm sorry your item is missing. I've escalated this to our "
                    "fulfilment centre and will reship your order within 24 hours.",
    }

    DEFAULT_RESPONSE = (
        "I'm your Order Agent. I can help with order tracking, cancellations, returns, "
        "exchanges, and shipping. Please provide your order number to get started."
    )

    def __init__(self, memory_store: MemoryStore):
        super().__init__("OrderAgent", memory_store)

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "").lower()

        # Retrieve or generate a mock order context
        order_id  = self.get_context(session_id, "order_id") or _random_order_id()
        self.set_context(session_id, "order_id", order_id)

        response = self._generate_response(text, order_id)

        self.logger.info(f"[{session_id}] OrderAgent responded | order_id={order_id}")
        return response

    def _generate_response(self, text: str, order_id: str) -> str:
        eta      = "April 28, 2026"
        tracking = f"TRACK-{order_id[-6:].upper()}"
        amount   = f"{random.randint(10, 200)}.00"

        for keyword, reply in self.KEYWORDS.items():
            if keyword in text:
                return reply.format(eta=eta, tracking=tracking, amount=amount)

        return self.DEFAULT_RESPONSE


def _random_order_id() -> str:
    return "ORD-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
