"""
agents/tech_agent.py
────────────────────
Handles technical support queries: bugs, errors, connectivity, setup, etc.

Phase 1 → rule-based responses + shared memory (tracks open tickets)
Phase 2 → replace _generate_response() with AWS Bedrock call
"""

from agents.base_agent import BaseAgent
from memory.memory_store import MemoryStore


class TechAgent(BaseAgent):

    KEYWORDS = {
        "error":       "I've logged the error report. Common fixes: clear your cache, "
                       "restart the app, or check our status page at status.example.com. "
                       "If the issue persists, I'll escalate to Tier 2 support.",
        "crash":       "I'm sorry the application crashed. Please share the error log "
                       "or screenshot and I'll diagnose the root cause immediately.",
        "slow":        "Performance issues are usually caused by network latency or "
                       "a resource spike on our end. I'm running diagnostics now.",
        "login":       "Login issues can be caused by expired sessions or 2FA problems. "
                       "Try resetting your password, or I can send a magic link.",
        "password":    "I'll send a secure password-reset link to your registered email "
                       "within the next 60 seconds.",
        "install":     "Installation guide: download the latest version from our portal, "
                       "run the installer as Administrator, and restart your machine.",
        "bug":         "Thank you for reporting this bug. I've opened ticket #TKT-"
                       "{}. Our engineering team will investigate within 24 hours.",
        "update":      "The latest version is 4.2.1. You can update via Settings → "
                       "About → Check for Updates, or download it from our portal.",
        "api":         "For API issues, verify your API key is active and that you're "
                       "hitting the correct endpoint. Check our docs at docs.example.com.",
        "connectivity":"Connectivity issues often stem from firewall rules or DNS. "
                       "Try pinging api.example.com and share the output.",
        "setup":       "I'll walk you through the setup step by step. What operating "
                       "system are you on — Windows, macOS, or Linux?",
    }

    DEFAULT_RESPONSE = (
        "I'm your Tech Support Agent. I can help with errors, crashes, login issues, "
        "bugs, and configuration. Could you describe the problem in more detail?"
    )

    def __init__(self, memory_store: MemoryStore):
        super().__init__("TechAgent", memory_store)
        self._ticket_counter = 1000

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "").lower()

        # Track open tickets in shared memory
        open_tickets = self.get_context(session_id, "open_tickets", [])
        response     = self._generate_response(text, open_tickets)

        # If a new ticket was created, persist it
        if "TKT-" in response:
            ticket_id = f"TKT-{self._ticket_counter}"
            self._ticket_counter += 1
            open_tickets.append(ticket_id)
            self.set_context(session_id, "open_tickets", open_tickets)
            response = response.format(self._ticket_counter)

        self.logger.info(f"[{session_id}] TechAgent responded | tickets={open_tickets}")
        return response

    def _generate_response(self, text: str, open_tickets: list) -> str:
        if open_tickets:
            prefix = f"(You have {len(open_tickets)} open ticket(s): {', '.join(open_tickets)}) "
        else:
            prefix = ""

        for keyword, reply in self.KEYWORDS.items():
            if keyword in text:
                return prefix + reply

        return prefix + self.DEFAULT_RESPONSE
