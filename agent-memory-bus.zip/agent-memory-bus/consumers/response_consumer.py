"""
consumers/response_consumer.py
───────────────────────────────
Reads from `agent.response` and pretty-prints every agent reply in real time.
Also supports tailing the `agent.audit` topic for observability.

Usage:
    # Watch responses
    python consumers/response_consumer.py

    # Watch audit trail instead
    python consumers/response_consumer.py --topic audit
"""

import argparse
import json
import sys

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable

sys.path.insert(0, ".")
from config.settings import KAFKA_BROKER, KAFKA_GROUP_ID, TOPICS, get_logger

logger = get_logger("ResponseConsumer")

AGENT_COLOURS = {
    "BillingAgent": "\033[94m",   # blue
    "TechAgent":    "\033[92m",   # green
    "OrderAgent":   "\033[93m",   # yellow
    "Orchestrator": "\033[95m",   # magenta
}
RESET  = "\033[0m"
BOLD   = "\033[1m"
CYAN   = "\033[96m"
RED    = "\033[91m"


def build_consumer(topic_key: str) -> KafkaConsumer:
    topic = TOPICS[topic_key]
    try:
        consumer = KafkaConsumer(
            topic,
            bootstrap_servers=KAFKA_BROKER,
            group_id=f"{KAFKA_GROUP_ID}-consumer-{topic_key}",
            auto_offset_reset="latest",
            enable_auto_commit=True,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        )
        logger.info(f"Consumer connected — topic: {topic}")
        return consumer
    except NoBrokersAvailable:
        logger.error(
            f"Cannot connect to Kafka at {KAFKA_BROKER}. "
            "Is Docker running?"
        )
        sys.exit(1)


def display_response(msg: dict) -> None:
    agent_id   = msg.get("agent_id", "Unknown")
    session_id = msg.get("session_id", "?")
    user_id    = msg.get("user_id", "?")
    response   = msg.get("response", "")
    timestamp  = msg.get("timestamp", "")

    colour = AGENT_COLOURS.get(agent_id, "\033[97m")

    print(f"\n{'─' * 65}")
    print(f"  {BOLD}{colour}[{agent_id}]{RESET}  {CYAN}{timestamp[11:19]}{RESET}")
    print(f"  {BOLD}Session:{RESET} {session_id[:8]}…  {BOLD}User:{RESET} {user_id}")
    print(f"  {BOLD}Response:{RESET}")
    # Word-wrap at 60 chars
    words = response.split()
    line  = "    "
    for word in words:
        if len(line) + len(word) > 64:
            print(line)
            line = "    "
        line += word + " "
    if line.strip():
        print(line)
    print(f"{'─' * 65}")


def display_audit(msg: dict) -> None:
    agent_id   = msg.get("agent_id", "?")
    session_id = msg.get("session_id", "?")
    event_type = msg.get("event_type", "?")
    payload    = msg.get("payload", {})
    timestamp  = msg.get("timestamp", "")

    colour = AGENT_COLOURS.get(agent_id, "\033[97m")
    print(
        f"  {CYAN}{timestamp[11:19]}{RESET} "
        f"{colour}[{agent_id}]{RESET} "
        f"{BOLD}{event_type}{RESET} "
        f"session={session_id[:8]}…"
    )
    if payload:
        for k, v in payload.items():
            v_str = str(v)[:80]
            print(f"    {k}: {v_str}")


def run(topic_key: str) -> None:
    consumer   = build_consumer(topic_key)
    is_audit   = topic_key == "audit"

    print(f"\n  {BOLD}Agent Memory Bus — {'Audit Trail' if is_audit else 'Response Stream'}{RESET}")
    print(f"  Topic: {TOPICS[topic_key]}  |  Broker: {KAFKA_BROKER}")
    print("  Waiting for messages … (Ctrl+C to quit)\n")

    try:
        for kafka_msg in consumer:
            msg = kafka_msg.value
            if is_audit:
                display_audit(msg)
            else:
                display_response(msg)
    except KeyboardInterrupt:
        print("\n  Consumer stopped.")
    finally:
        consumer.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Agent Memory Bus — Consumer")
    parser.add_argument(
        "--topic",
        choices=["response", "audit", "memory"],
        default="response",
        help="Which topic to consume (default: response)",
    )
    args = parser.parse_args()
    run(args.topic)


if __name__ == "__main__":
    main()
