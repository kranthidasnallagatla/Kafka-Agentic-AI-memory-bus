"""
memory/memory_store.py
──────────────────────
Thread-safe shared memory layer for all agents.

Phase 1 → in-memory dictionary (fast, no infra needed)
Phase 2 → swap _backend calls to DynamoDB (stubs included below)

Every agent reads/writes through this interface, which is how the bus
achieves shared, consistent memory across independent agent processes.
"""

import threading
from datetime import datetime
from typing import Any, Optional
from config.settings import get_logger

logger = get_logger("MemoryStore")


class MemoryStore:
    """
    Shared memory accessible by all agents.

    Schema per session:
    {
        "session_id": {
            "user_id":       str,
            "history":       [{"role": str, "content": str, "ts": str}],
            "context":       {},   # arbitrary key-value facts
            "last_agent":    str,
            "last_updated":  str,
        }
    }
    """

    def __init__(self):
        self._store: dict[str, dict] = {}
        self._lock = threading.RLock()
        logger.info("MemoryStore initialised (in-memory backend)")

    # ── Public API ─────────────────────────────────────────────────────────

    def get(self, session_id: str) -> dict:
        """Return the full memory record for a session (empty dict if none)."""
        with self._lock:
            return dict(self._store.get(session_id, {}))

    def update(self, session_id: str, key: str, value: Any) -> None:
        """Set an arbitrary key inside a session's memory."""
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["context"][key] = value
            self._store[session_id]["last_updated"] = _now()
        logger.debug(f"[{session_id}] memory.update → {key}={value}")

    def append_history(self, session_id: str, role: str, content: str) -> None:
        """Append a message (user or assistant) to the conversation history."""
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["history"].append({
                "role":    role,
                "content": content,
                "ts":      _now(),
            })
            self._store[session_id]["last_updated"] = _now()

    def set_last_agent(self, session_id: str, agent_id: str) -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["last_agent"]   = agent_id
            self._store[session_id]["last_updated"] = _now()

    def get_history(self, session_id: str) -> list:
        with self._lock:
            return list(self._store.get(session_id, {}).get("history", []))

    def get_context(self, session_id: str, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._store.get(session_id, {}).get("context", {}).get(key, default)

    def clear_session(self, session_id: str) -> None:
        with self._lock:
            self._store.pop(session_id, None)
        logger.info(f"[{session_id}] session cleared from memory")

    def all_sessions(self) -> list[str]:
        with self._lock:
            return list(self._store.keys())

    # ── Private ────────────────────────────────────────────────────────────

    def _ensure_session(self, session_id: str) -> None:
        """Create a blank session record if one doesn't exist yet."""
        if session_id not in self._store:
            self._store[session_id] = {
                "session_id":   session_id,
                "history":      [],
                "context":      {},
                "last_agent":   None,
                "last_updated": _now(),
                "created_at":   _now(),
            }
            logger.info(f"[{session_id}] new session created in memory")


# ── Phase 2: DynamoDB backend stub ────────────────────────────────────────
#
# class DynamoMemoryStore:
#     """Drop-in replacement for MemoryStore backed by AWS DynamoDB."""
#
#     def __init__(self, table_name: str, region: str):
#         import boto3
#         self._table = boto3.resource("dynamodb", region_name=region).Table(table_name)
#
#     def get(self, session_id: str) -> dict:
#         resp = self._table.get_item(Key={"session_id": session_id})
#         return resp.get("Item", {})
#
#     def update(self, session_id: str, key: str, value) -> None:
#         self._table.update_item(
#             Key={"session_id": session_id},
#             UpdateExpression="SET #ctx.#k = :v, last_updated = :ts",
#             ExpressionAttributeNames={"#ctx": "context", "#k": key},
#             ExpressionAttributeValues={":v": value, ":ts": _now()},
#         )
#
#   ... (append_history, set_last_agent follow same pattern)


def _now() -> str:
    return datetime.utcnow().isoformat()
