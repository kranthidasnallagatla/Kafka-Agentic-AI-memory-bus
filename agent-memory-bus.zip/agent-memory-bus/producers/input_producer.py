"""
producers/input_producer.py
───────────────────────────
Publishes user messages to the `agent.input` Kafka topic.

Usage:
    # Interactive mode — type messages in the terminal
    python producers/input_producer.py

    # Send a single message via CLI
    python producers/input_producer.py --text "I have a billing issue" --session abc123

    # Run the built-in demo sequence
    python producers/input_producer.py --demo
"""

import argparse
import json
import sys
import uuid
from datetime import datetime

from kafka import KafkaProducer
from kafka.errors import NoBrokersAvailable

sys.path.insert(0, ".")
from config.settings import KAFKA_BROKER, TOPICS, get_logger

logger = get_logger("InputProducer")

# Demo messages that exercise all three agents
DEMO_MESSAGES = [
    ("user-001", "I need help with my invoice — there's a duplicate charge."),
    ("user-002", "The app keeps crashing when I open the dashboard."),
    ("user-003", "Where is my order? It was supposed to arrive yesterday."),
    ("user-001", "Can I get a refund for the extra charge?"),
    ("user-002", "I also can't log in — my password isn't working."),
    ("user-003", "I want to return the item I received."),
    ("user-004", "How do I install the desktop app on Windows?"),
    ("user-005", "Can you give me a discount on my subscription?"),
]


def build_producer() -> KafkaProducer:
    try:
        producer = KafkaProducer(
            bootstrap_servers=KAFKA_BROKER,
            retries=5,
            acks="all",
            linger_ms=5,
        )
        logger.info(f"Producer connected to {KAFKA_BROKER}")
        return producer
    except NoBrokersAvailable:
        logger.error(
            f"Cannot connect to Kafka at {KAFKA_BROKER}. "
            "Is Docker running? Did you run scripts/create_topics.sh?"
        )
        sys.exit(1)


def send_message(producer: KafkaProducer, text: str, user_id: str, session_id: str) -> None:
    payload = {
        "session_id": session_id,
        "user_id":    user_id,
        "text":       text,
        "metadata":   {},
        "timestamp":  datetime.utcnow().isoformat(),
    }
    encoded = json.dumps(payload).encode("utf-8")
    future  = producer.send(TOPICS["input"], key=session_id.encode("utf-8"), value=encoded)
    producer.flush()
    record_meta = future.get(timeout=10)
    logger.info(
        f"→ Sent | session={session_id} user={user_id} "
        f"topic={record_meta.topic} partition={record_meta.partition} "
        f"offset={record_meta.offset}"
    )
    print(f'\n  📤  "{text}"')


def run_demo(producer: KafkaProducer) -> None:
    logger.info("Running demo sequence ...")
    sessions: dict[str, str] = {}

    for user_id, text in DEMO_MESSAGES:
        # Give each user a consistent session so memory is maintained
        if user_id not in sessions:
            sessions[user_id] = str(uuid.uuid4())
        send_message(producer, text, user_id, sessions[user_id])

    logger.info("Demo complete — check the response consumer output.")


def run_interactive(producer: KafkaProducer) -> None:
    session_id = str(uuid.uuid4())
    user_id    = "interactive-user"
    print(f"\n  Agent Memory Bus — Interactive Producer")
    print(f"  Session: {session_id}")
    print("  Type your message and press Enter. Ctrl+C to quit.\n")

    try:
        while True:
            text = input("  You: ").strip()
            if not text:
                continue
            send_message(producer, text, user_id, session_id)
    except KeyboardInterrupt:
        print("\n  Goodbye!")


def main() -> None:
    parser = argparse.ArgumentParser(description="Agent Memory Bus — Input Producer")
    parser.add_argument("--text",    help="Single message text to send")
    parser.add_argument("--session", help="Session ID (auto-generated if omitted)")
    parser.add_argument("--user",    default="cli-user", help="User ID")
    parser.add_argument("--demo",    action="store_true", help="Run built-in demo sequence")
    args = parser.parse_args()

    producer = build_producer()

    if args.demo:
        run_demo(producer)
    elif args.text:
        session_id = args.session or str(uuid.uuid4())
        send_message(producer, args.text, args.user, session_id)
    else:
        run_interactive(producer)

    producer.close()


if __name__ == "__main__":
    main()
