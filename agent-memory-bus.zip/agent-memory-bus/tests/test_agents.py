"""
tests/test_agents.py
────────────────────
Unit tests for all three agents + the intent classifier.
No Kafka or Docker required — Kafka producer is mocked.

Run:  python -m pytest tests/test_agents.py -v
  or: python tests/test_agents.py
"""

import sys
import json
import uuid
from unittest.mock import MagicMock, patch
sys.path.insert(0, ".")

from memory.memory_store import MemoryStore


# ── Shared fixtures ────────────────────────────────────────────────────────

def make_message(text: str, session_id: str = None) -> dict:
    return {
        "session_id": session_id or str(uuid.uuid4()),
        "user_id":    "test-user",
        "text":       text,
        "metadata":   {},
    }


def make_agent(AgentClass):
    """Instantiate an agent with a real MemoryStore but a mocked Kafka producer."""
    memory = MemoryStore()
    with patch("agents.base_agent.KafkaProducer") as MockProducer:
        mock_producer = MagicMock()
        mock_future   = MagicMock()
        mock_future.get.return_value = MagicMock(topic="agent.response", partition=0, offset=1)
        mock_producer.send.return_value = mock_future
        MockProducer.return_value = mock_producer
        agent = AgentClass(memory)
        agent._producer = mock_producer   # ensure the mock is used
    return agent, memory


# ── BillingAgent ──────────────────────────────────────────────────────────

def test_billing_invoice():
    from agents.billing_agent import BillingAgent
    agent, _ = make_agent(BillingAgent)
    response = agent.handle(make_message("I need my invoice"))
    assert "invoice" in response.lower()
    print("✅  test_billing_invoice")


def test_billing_refund():
    from agents.billing_agent import BillingAgent
    agent, _ = make_agent(BillingAgent)
    response = agent.handle(make_message("I want a refund"))
    assert "refund" in response.lower()
    print("✅  test_billing_refund")


def test_billing_visit_counter():
    from agents.billing_agent import BillingAgent
    agent, memory = make_agent(BillingAgent)
    sid = str(uuid.uuid4())
    agent.handle(make_message("billing question", sid))
    agent.handle(make_message("billing question", sid))
    count = memory.get_context(sid, "billing_visits")
    assert count == 2, f"Expected 2, got {count}"
    print("✅  test_billing_visit_counter")


def test_billing_default_response():
    from agents.billing_agent import BillingAgent
    agent, _ = make_agent(BillingAgent)
    response = agent.handle(make_message("ghjklzxcv"))
    assert len(response) > 0
    print("✅  test_billing_default_response")


# ── TechAgent ─────────────────────────────────────────────────────────────

def test_tech_error():
    from agents.tech_agent import TechAgent
    agent, _ = make_agent(TechAgent)
    response = agent.handle(make_message("I keep getting an error"))
    assert len(response) > 0
    print("✅  test_tech_error")


def test_tech_password():
    from agents.tech_agent import TechAgent
    agent, _ = make_agent(TechAgent)
    response = agent.handle(make_message("I forgot my password"))
    assert "password" in response.lower() or "reset" in response.lower()
    print("✅  test_tech_password")


def test_tech_ticket_stored_in_memory():
    from agents.tech_agent import TechAgent
    agent, memory = make_agent(TechAgent)
    sid = str(uuid.uuid4())
    agent.handle(make_message("There is a bug in the dashboard", sid))
    tickets = memory.get_context(sid, "open_tickets", [])
    # Ticket list should be accessible (may be empty if no TKT- in response)
    assert isinstance(tickets, list)
    print("✅  test_tech_ticket_stored_in_memory")


def test_tech_default_response():
    from agents.tech_agent import TechAgent
    agent, _ = make_agent(TechAgent)
    response = agent.handle(make_message("asdfghjkl"))
    assert len(response) > 0
    print("✅  test_tech_default_response")


# ── OrderAgent ────────────────────────────────────────────────────────────

def test_order_track():
    from agents.order_agent import OrderAgent
    agent, _ = make_agent(OrderAgent)
    response = agent.handle(make_message("Can you track my order?"))
    assert "track" in response.lower() or "deliver" in response.lower() or "transit" in response.lower()
    print("✅  test_order_track")


def test_order_return():
    from agents.order_agent import OrderAgent
    agent, _ = make_agent(OrderAgent)
    response = agent.handle(make_message("I want to return my item"))
    assert "return" in response.lower()
    print("✅  test_order_return")


def test_order_id_persisted_in_memory():
    from agents.order_agent import OrderAgent
    agent, memory = make_agent(OrderAgent)
    sid = str(uuid.uuid4())
    agent.handle(make_message("where is my order", sid))
    order_id = memory.get_context(sid, "order_id")
    assert order_id is not None
    assert order_id.startswith("ORD-")
    print("✅  test_order_id_persisted_in_memory")


def test_order_same_order_id_across_turns():
    from agents.order_agent import OrderAgent
    agent, memory = make_agent(OrderAgent)
    sid = str(uuid.uuid4())
    agent.handle(make_message("track my order", sid))
    id1 = memory.get_context(sid, "order_id")
    agent.handle(make_message("I want to cancel it", sid))
    id2 = memory.get_context(sid, "order_id")
    assert id1 == id2, "Order ID should stay stable within a session"
    print("✅  test_order_same_order_id_across_turns")


# ── Orchestrator intent classifier ────────────────────────────────────────

def test_classify_billing():
    from agents.orchestrator import Orchestrator
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"):
        orch = Orchestrator()
    assert orch._classify_intent("my invoice is wrong") == "billing"
    print("✅  test_classify_billing")


def test_classify_tech():
    from agents.orchestrator import Orchestrator
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"):
        orch = Orchestrator()
    assert orch._classify_intent("the app keeps crashing") == "tech"
    print("✅  test_classify_tech")


def test_classify_order():
    from agents.orchestrator import Orchestrator
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"):
        orch = Orchestrator()
    assert orch._classify_intent("where is my package") == "order"
    print("✅  test_classify_order")


def test_classify_unknown_falls_back():
    from agents.orchestrator import Orchestrator
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"):
        orch = Orchestrator()
    result = orch._classify_intent("xyzzy frobnicator blorp")
    assert result in ("billing", "tech", "order")
    print("✅  test_classify_unknown_falls_back")


# ── Shared memory across agents ───────────────────────────────────────────

def test_shared_memory_across_agents():
    """BillingAgent writes context; OrderAgent reads the same MemoryStore."""
    from agents.billing_agent import BillingAgent
    from agents.order_agent   import OrderAgent

    memory   = MemoryStore()
    sid      = str(uuid.uuid4())

    with patch("agents.base_agent.KafkaProducer") as MP:
        mp = MagicMock()
        mf = MagicMock()
        mf.get.return_value = MagicMock()
        mp.send.return_value = mf
        MP.return_value = mp

        billing = BillingAgent(memory)
        order   = OrderAgent(memory)

    # BillingAgent sets a context value
    billing.set_context(sid, "vip_customer", True)

    # OrderAgent reads the same memory for the same session
    val = order.get_context(sid, "vip_customer")
    assert val is True, f"Expected True, got {val}"
    print("✅  test_shared_memory_across_agents")


# ── Runner ─────────────────────────────────────────────────────────────────

ALL_TESTS = [
    test_billing_invoice,
    test_billing_refund,
    test_billing_visit_counter,
    test_billing_default_response,
    test_tech_error,
    test_tech_password,
    test_tech_ticket_stored_in_memory,
    test_tech_default_response,
    test_order_track,
    test_order_return,
    test_order_id_persisted_in_memory,
    test_order_same_order_id_across_turns,
    test_classify_billing,
    test_classify_tech,
    test_classify_order,
    test_classify_unknown_falls_back,
    test_shared_memory_across_agents,
]

if __name__ == "__main__":
    print("\n  Running Agent tests ...\n")
    passed = 0
    for test in ALL_TESTS:
        test()
        passed += 1
    print(f"\n  {passed}/{len(ALL_TESTS)} tests passed ✅\n")
