"""
tests/test_producer.py
──────────────────────
Unit tests for the InputProducer.
No Kafka or Docker required — producer is mocked.

Run:  python -m pytest tests/test_producer.py -v
  or: python tests/test_producer.py
"""

import json
import sys
import uuid
from unittest.mock import MagicMock, patch
sys.path.insert(0, ".")


def make_mock_producer():
    producer   = MagicMock()
    future     = MagicMock()
    record_meta = MagicMock()
    record_meta.topic     = "agent.input"
    record_meta.partition = 0
    record_meta.offset    = 42
    future.get.return_value     = record_meta
    producer.send.return_value  = future
    return producer


def test_send_message_calls_producer():
    from producers.input_producer import send_message
    producer   = make_mock_producer()
    session_id = str(uuid.uuid4())
    send_message(producer, "billing problem", "user-1", session_id)
    assert producer.send.called
    print("✅  test_send_message_calls_producer")


def test_send_message_payload_structure():
    from producers.input_producer import send_message
    producer   = make_mock_producer()
    session_id = str(uuid.uuid4())
    text       = "I need a refund"
    send_message(producer, text, "user-42", session_id)

    call_args = producer.send.call_args
    topic     = call_args[0][0]
    key       = call_args[1]["key"].decode("utf-8")
    payload   = json.loads(call_args[1]["value"].decode("utf-8"))

    assert topic               == "agent.input"
    assert key                 == session_id
    assert payload["text"]     == text
    assert payload["user_id"]  == "user-42"
    assert payload["session_id"] == session_id
    assert "timestamp" in payload
    print("✅  test_send_message_payload_structure")


def test_send_message_flushes():
    from producers.input_producer import send_message
    producer   = make_mock_producer()
    send_message(producer, "test", "user-1", str(uuid.uuid4()))
    assert producer.flush.called
    print("✅  test_send_message_flushes")


def test_demo_sends_correct_number_of_messages():
    from producers.input_producer import run_demo, DEMO_MESSAGES
    producer = make_mock_producer()
    run_demo(producer)
    assert producer.send.call_count == len(DEMO_MESSAGES)
    print(f"✅  test_demo_sends_correct_number_of_messages ({len(DEMO_MESSAGES)} messages)")


def test_same_user_gets_consistent_session_in_demo():
    from producers.input_producer import run_demo, DEMO_MESSAGES
    producer   = make_mock_producer()
    run_demo(producer)

    # Collect all (user_id → session_id) pairs from call args
    sessions_by_user: dict[str, set] = {}
    for call in producer.send.call_args_list:
        payload = json.loads(call[1]["value"].decode("utf-8"))
        uid     = payload["user_id"]
        sid     = payload["session_id"]
        sessions_by_user.setdefault(uid, set()).add(sid)

    # Each user should have exactly one unique session
    for uid, sids in sessions_by_user.items():
        assert len(sids) == 1, (
            f"user {uid} got multiple sessions: {sids}"
        )
    print("✅  test_same_user_gets_consistent_session_in_demo")


# ── Runner ──────────────────────────────────────────────────────────────────

ALL_TESTS = [
    test_send_message_calls_producer,
    test_send_message_payload_structure,
    test_send_message_flushes,
    test_demo_sends_correct_number_of_messages,
    test_same_user_gets_consistent_session_in_demo,
]

if __name__ == "__main__":
    print("\n  Running InputProducer tests ...\n")
    passed = 0
    for test in ALL_TESTS:
        test()
        passed += 1
    print(f"\n  {passed}/{len(ALL_TESTS)} tests passed ✅\n")
