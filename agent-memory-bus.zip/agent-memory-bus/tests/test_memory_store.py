"""
tests/test_memory_store.py
──────────────────────────
Unit tests for the shared MemoryStore.
No Kafka or Docker required — pure in-process tests.

Run:  python -m pytest tests/test_memory_store.py -v
  or: python tests/test_memory_store.py
"""

import sys
import threading
sys.path.insert(0, ".")

from memory.memory_store import MemoryStore


# ── Helpers ────────────────────────────────────────────────────────────────

def make_store() -> MemoryStore:
    return MemoryStore()


# ── Tests ──────────────────────────────────────────────────────────────────

def test_get_empty_session():
    store = make_store()
    result = store.get("nonexistent-session")
    assert result == {}, f"Expected empty dict, got {result}"
    print("✅  test_get_empty_session")


def test_update_and_get_context():
    store = make_store()
    sid   = "sess-001"
    store.update(sid, "plan", "enterprise")
    assert store.get_context(sid, "plan") == "enterprise"
    print("✅  test_update_and_get_context")


def test_default_context_value():
    store = make_store()
    val = store.get_context("no-session", "missing_key", default="fallback")
    assert val == "fallback"
    print("✅  test_default_context_value")


def test_append_history():
    store = make_store()
    sid   = "sess-002"
    store.append_history(sid, "user",      "Hello")
    store.append_history(sid, "assistant", "Hi! How can I help?")
    history = store.get_history(sid)
    assert len(history) == 2
    assert history[0]["role"]    == "user"
    assert history[0]["content"] == "Hello"
    assert history[1]["role"]    == "assistant"
    print("✅  test_append_history")


def test_set_last_agent():
    store = make_store()
    sid   = "sess-003"
    store.set_last_agent(sid, "BillingAgent")
    record = store.get(sid)
    assert record["last_agent"] == "BillingAgent"
    print("✅  test_set_last_agent")


def test_clear_session():
    store = make_store()
    sid   = "sess-004"
    store.update(sid, "foo", "bar")
    store.clear_session(sid)
    assert store.get(sid) == {}
    print("✅  test_clear_session")


def test_all_sessions():
    store = make_store()
    store.update("s1", "k", "v")
    store.update("s2", "k", "v")
    store.update("s3", "k", "v")
    sessions = store.all_sessions()
    assert "s1" in sessions
    assert "s2" in sessions
    assert "s3" in sessions
    print("✅  test_all_sessions")


def test_thread_safety():
    """Multiple threads writing different sessions must not corrupt state."""
    store   = make_store()
    errors  = []

    def write(session_id, value):
        try:
            for _ in range(50):
                store.update(session_id, "counter", value)
                store.append_history(session_id, "user", f"msg-{value}")
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=write, args=(f"sess-{i}", i)) for i in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, f"Thread-safety errors: {errors}"
    print("✅  test_thread_safety")


def test_history_is_ordered():
    store = make_store()
    sid   = "sess-005"
    messages = ["first", "second", "third", "fourth"]
    for m in messages:
        store.append_history(sid, "user", m)
    history = store.get_history(sid)
    contents = [h["content"] for h in history]
    assert contents == messages
    print("✅  test_history_is_ordered")


def test_multiple_context_keys():
    store = make_store()
    sid   = "sess-006"
    store.update(sid, "plan",   "pro")
    store.update(sid, "region", "us-east-1")
    store.update(sid, "tier",   3)
    assert store.get_context(sid, "plan")   == "pro"
    assert store.get_context(sid, "region") == "us-east-1"
    assert store.get_context(sid, "tier")   == 3
    print("✅  test_multiple_context_keys")


# ── Runner ─────────────────────────────────────────────────────────────────

ALL_TESTS = [
    test_get_empty_session,
    test_update_and_get_context,
    test_default_context_value,
    test_append_history,
    test_set_last_agent,
    test_clear_session,
    test_all_sessions,
    test_thread_safety,
    test_history_is_ordered,
    test_multiple_context_keys,
]

if __name__ == "__main__":
    print("\n  Running MemoryStore tests ...\n")
    passed = 0
    for test in ALL_TESTS:
        test()
        passed += 1
    print(f"\n  {passed}/{len(ALL_TESTS)} tests passed ✅\n")
