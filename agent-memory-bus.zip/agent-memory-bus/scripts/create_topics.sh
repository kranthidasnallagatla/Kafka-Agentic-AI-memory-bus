#!/usr/bin/env bash
# scripts/create_topics.sh
# ─────────────────────────
# Creates all four Kafka topics for the Agent Memory Bus.
# Run this ONCE after `docker compose up -d` and Kafka is healthy.

set -euo pipefail

CONTAINER="agentbus-kafka"
BROKER="localhost:9092"
PARTITIONS=3
REPLICATION=1

TOPICS=(
  "agent.input"
  "agent.memory"
  "agent.response"
  "agent.audit"
)

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   Agent Memory Bus — Topic Setup     ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# Wait for Kafka to be reachable
echo "  ⏳  Waiting for Kafka to be ready ..."
for i in $(seq 1 20); do
  if docker exec "$CONTAINER" kafka-topics.sh \
      --bootstrap-server "$BROKER" --list &>/dev/null; then
    echo "  ✅  Kafka is ready."
    break
  fi
  if [ "$i" -eq 20 ]; then
    echo "  ❌  Kafka did not become ready in time. Is the container running?"
    exit 1
  fi
  sleep 3
done

echo ""

for TOPIC in "${TOPICS[@]}"; do
  # Check if topic already exists
  if docker exec "$CONTAINER" kafka-topics.sh \
      --bootstrap-server "$BROKER" \
      --describe --topic "$TOPIC" &>/dev/null; then
    echo "  ⚠️   Topic already exists — skipping: $TOPIC"
  else
    docker exec "$CONTAINER" kafka-topics.sh \
      --bootstrap-server "$BROKER" \
      --create \
      --topic "$TOPIC" \
      --partitions "$PARTITIONS" \
      --replication-factor "$REPLICATION"
    echo "  ✅  Created: $TOPIC  (partitions=$PARTITIONS)"
  fi
done

echo ""
echo "  📋  All topics:"
docker exec "$CONTAINER" kafka-topics.sh \
  --bootstrap-server "$BROKER" --list | sed 's/^/      /'
echo ""
echo "  ✅  Done. You can now start the Orchestrator and Producer."
echo ""
