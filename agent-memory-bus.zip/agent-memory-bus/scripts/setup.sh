#!/usr/bin/env bash
# scripts/setup.sh
# ─────────────────────────────────────────────────────────────────────────────
# One-shot setup for the Agent Memory Bus on WSL2 / Linux / macOS.
# Run this from the project root: bash scripts/setup.sh

set -euo pipefail

GREEN="\033[92m"
YELLOW="\033[93m"
CYAN="\033[96m"
BOLD="\033[1m"
RESET="\033[0m"

step() { echo -e "\n${BOLD}${CYAN}▶  $1${RESET}"; }
ok()   { echo -e "   ${GREEN}✅  $1${RESET}"; }
warn() { echo -e "   ${YELLOW}⚠️   $1${RESET}"; }

echo -e "\n${BOLD}╔══════════════════════════════════════════════╗"
echo    "║       Agent Memory Bus — Setup Script        ║"
echo -e "╚══════════════════════════════════════════════╝${RESET}"

# ── 1. Python deps ────────────────────────────────────────────────────────
step "Installing Python dependencies"
pip install -r requirements.txt -q
ok "Dependencies installed"

# ── 2. Environment file ───────────────────────────────────────────────────
step "Setting up environment"
if [ ! -f .env ]; then
  cp .env.example .env
  ok ".env created from .env.example"
else
  warn ".env already exists — skipping"
fi

# ── 3. Docker ─────────────────────────────────────────────────────────────
step "Starting Kafka + Zookeeper via Docker"
cd docker
docker compose up -d
cd ..
ok "Containers started"

# ── 4. Health check ───────────────────────────────────────────────────────
step "Waiting for Kafka to become healthy"
RETRIES=20
for i in $(seq 1 $RETRIES); do
  if docker exec agentbus-kafka kafka-topics.sh \
      --bootstrap-server localhost:9092 --list &>/dev/null 2>&1; then
    ok "Kafka is healthy"
    break
  fi
  if [ "$i" -eq "$RETRIES" ]; then
    echo -e "   \033[91m❌  Kafka did not start. Check: docker logs agentbus-kafka\033[0m"
    exit 1
  fi
  echo "   … attempt $i/$RETRIES"
  sleep 4
done

# ── 5. Create topics ──────────────────────────────────────────────────────
step "Creating Kafka topics"
bash scripts/create_topics.sh

# ── 6. Done ───────────────────────────────────────────────────────────────
echo -e "\n${BOLD}${GREEN}✅  Setup complete! Here's how to run the system:${RESET}\n"
echo    "   Terminal 1 — Orchestrator (the brain):"
echo -e "   ${CYAN}python agents/orchestrator.py${RESET}\n"
echo    "   Terminal 2 — Response stream:"
echo -e "   ${CYAN}python consumers/response_consumer.py${RESET}\n"
echo    "   Terminal 3 — Send test messages:"
echo -e "   ${CYAN}python producers/input_producer.py --demo${RESET}\n"
echo    "   Kafka UI → http://localhost:8080"
echo ""
