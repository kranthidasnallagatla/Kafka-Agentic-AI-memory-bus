"""
config/settings.py  —  Phase 2
────────────────────────────────
Reads all config from environment variables.
Set USE_LOCAL=true in .env to fall back to local Kafka + in-memory store
(same as Phase 1) without needing any AWS credentials.
"""

import os
import logging
import colorlog
from dotenv import load_dotenv

load_dotenv()

# ── Kafka ──────────────────────────────────────────────────────────────────
KAFKA_BROKER    = os.getenv("KAFKA_BROKER",    "localhost:9092")
KAFKA_GROUP_ID  = os.getenv("KAFKA_GROUP_ID",  "agent-memory-bus")
KAFKA_USE_TLS   = os.getenv("KAFKA_USE_TLS",   "false").lower() == "true"

TOPICS = {
    "input":    "agent.input",
    "memory":   "agent.memory",
    "response": "agent.response",
    "audit":    "agent.audit",
}

# ── AWS ────────────────────────────────────────────────────────────────────
AWS_REGION           = os.getenv("AWS_REGION",           "us-east-1")
AWS_ACCESS_KEY_ID    = os.getenv("AWS_ACCESS_KEY_ID",    "")
AWS_SECRET_ACCESS_KEY= os.getenv("AWS_SECRET_ACCESS_KEY","")

# ── DynamoDB ───────────────────────────────────────────────────────────────
DYNAMODB_TABLE       = os.getenv("DYNAMODB_TABLE",       "agent-memory")

# ── Bedrock ────────────────────────────────────────────────────────────────
BEDROCK_MODEL_ID     = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")
BEDROCK_MAX_TOKENS   = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))

# ── Local fallback ─────────────────────────────────────────────────────────
USE_LOCAL            = os.getenv("USE_LOCAL", "false").lower() == "true"

# ── Logging ────────────────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

def get_logger(name: str) -> logging.Logger:
    handler = colorlog.StreamHandler()
    handler.setFormatter(colorlog.ColoredFormatter(
        "%(log_color)s%(asctime)s [%(name)s] %(levelname)s%(reset)s — %(message)s",
        datefmt="%H:%M:%S",
        log_colors={
            "DEBUG":    "cyan",
            "INFO":     "green",
            "WARNING":  "yellow",
            "ERROR":    "red",
            "CRITICAL": "bold_red",
        },
    ))
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    if not logger.handlers:
        logger.addHandler(handler)
    return logger
