#!/usr/bin/env bash
# scripts/create_topics_msk.sh  —  Phase 2
# ──────────────────────────────────────────
# Creates the four Kafka topics on AWS MSK.
# Run once after your MSK cluster is active.
#
# Prerequisites:
#   - kafka-topics.sh available locally (download from kafka.apache.org)
#   - MSK cluster bootstrap broker URL in .env as KAFKA_BROKER
#
# Usage:
#   bash scripts/create_topics_msk.sh

set -euo pipefail

source .env 2>/dev/null || true

BROKER="${KAFKA_BROKER:-}"
PARTITIONS=3
REPLICATION=3     # 3 for MSK (matches 3 AZ broker count)

TOPICS=(
  "agent.input"
  "agent.memory"
  "agent.response"
  "agent.audit"
)

if [[ -z "$BROKER" ]]; then
  echo "  ❌  KAFKA_BROKER not set in .env"
  exit 1
fi

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║   Agent Memory Bus — MSK Topic Setup         ║"
echo "  ╚══════════════════════════════════════════════╝"
echo "  Broker: $BROKER"
echo ""

for TOPIC in "${TOPICS[@]}"; do
  echo -n "  Creating: $TOPIC ... "
  kafka-topics.sh \
    --bootstrap-server "$BROKER" \
    --create \
    --if-not-exists \
    --topic "$TOPIC" \
    --partitions "$PARTITIONS" \
    --replication-factor "$REPLICATION" \
    --config retention.ms=604800000 \
    --config min.insync.replicas=2
  echo "✅"
done

echo ""
echo "  All topics:"
kafka-topics.sh --bootstrap-server "$BROKER" --list | sed 's/^/    /'
echo ""
