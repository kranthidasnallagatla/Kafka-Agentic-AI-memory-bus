#!/usr/bin/env bash
# scripts/setup_phase2.sh
# ────────────────────────
# Phase 2 setup checklist — walks through each AWS step.

set -euo pipefail

GREEN="\033[92m"; YELLOW="\033[93m"; CYAN="\033[96m"; BOLD="\033[1m"; RESET="\033[0m"
step() { echo -e "\n${BOLD}${CYAN}▶  $1${RESET}"; }
ok()   { echo -e "   ${GREEN}✅  $1${RESET}"; }
warn() { echo -e "   ${YELLOW}⚠️   $1${RESET}"; }

echo -e "\n${BOLD}╔══════════════════════════════════════════════╗"
echo    "║   Agent Memory Bus — Phase 2 Setup           ║"
echo -e "╚══════════════════════════════════════════════╝${RESET}"

# 1. Python deps
step "Installing Python dependencies"
pip install -r requirements.txt -q
ok "Dependencies installed"

# 2. .env
step "Environment file"
if [ ! -f .env ]; then
  cp .env.example .env
  warn ".env created — fill in your AWS credentials and MSK broker URL before continuing"
  echo "  Edit .env now, then re-run this script."
  exit 0
else
  ok ".env exists"
fi

# 3. AWS CLI check
step "Checking AWS credentials"
if aws sts get-caller-identity &>/dev/null; then
  ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
  ok "AWS credentials valid — account: $ACCOUNT"
else
  warn "AWS credentials not configured. Run: aws configure"
  exit 1
fi

# 4. DynamoDB
step "Creating DynamoDB table"
python scripts/create_dynamo_table.py
ok "DynamoDB ready"

# 5. MSK topics
step "Creating MSK topics"
bash scripts/create_topics_msk.sh
ok "MSK topics ready"

# 6. Done
echo -e "\n${BOLD}${GREEN}✅  Phase 2 setup complete!${RESET}\n"
echo "  Start system:"
echo -e "  ${CYAN}python agents/orchestrator.py${RESET}            # Terminal 1"
echo -e "  ${CYAN}python consumers/response_consumer.py${RESET}    # Terminal 2"
echo -e "  ${CYAN}python producers/input_producer.py --demo${RESET} # Terminal 3"
echo ""
