"""
scripts/create_dynamo_table.py  —  Phase 2
────────────────────────────────────────────
Creates the DynamoDB table for shared agent memory.
Run once before starting the system.

Usage:
    python scripts/create_dynamo_table.py
    python scripts/create_dynamo_table.py --delete   # drop and recreate
"""

import sys
import argparse
import boto3
from botocore.exceptions import ClientError

sys.path.insert(0, ".")
from config.settings import AWS_REGION, DYNAMODB_TABLE, get_logger

logger = get_logger("DynamoSetup")


def create_table(client, table_name: str) -> None:
    logger.info(f"Creating DynamoDB table: {table_name}")
    try:
        client.create_table(
            TableName=table_name,
            KeySchema=[
                {"AttributeName": "session_id", "KeyType": "HASH"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "session_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",   # On-demand — no capacity planning needed
            Tags=[
                {"Key": "Project", "Value": "agent-memory-bus"},
                {"Key": "Phase",   "Value": "2"},
            ],
        )
        # Wait until the table is active
        waiter = client.get_waiter("table_exists")
        waiter.wait(TableName=table_name)
        logger.info(f"Table '{table_name}' created and active ✓")

    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code == "ResourceInUseException":
            logger.warning(f"Table '{table_name}' already exists — skipping.")
        else:
            logger.error(f"Failed to create table: {e}")
            sys.exit(1)


def delete_table(client, table_name: str) -> None:
    logger.info(f"Deleting table: {table_name}")
    try:
        client.delete_table(TableName=table_name)
        waiter = client.get_waiter("table_not_exists")
        waiter.wait(TableName=table_name)
        logger.info(f"Table '{table_name}' deleted.")
    except ClientError as e:
        logger.error(f"Delete failed: {e}")
        sys.exit(1)


def describe_table(client, table_name: str) -> None:
    try:
        resp  = client.describe_table(TableName=table_name)
        table = resp["Table"]
        print(f"\n  Table:        {table['TableName']}")
        print(f"  Status:       {table['TableStatus']}")
        print(f"  Billing:      {table.get('BillingModeSummary', {}).get('BillingMode', 'PROVISIONED')}")
        print(f"  Item count:   {table.get('ItemCount', 0)}")
        print(f"  Size (bytes): {table.get('TableSizeBytes', 0)}")
        print()
    except ClientError:
        print(f"  Table '{table_name}' does not exist yet.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="DynamoDB table setup for Agent Memory Bus")
    parser.add_argument("--delete", action="store_true", help="Delete and recreate the table")
    args = parser.parse_args()

    client = boto3.client("dynamodb", region_name=AWS_REGION)

    print(f"\n  Agent Memory Bus — DynamoDB Setup")
    print(f"  Region: {AWS_REGION}  |  Table: {DYNAMODB_TABLE}\n")
    describe_table(client, DYNAMODB_TABLE)

    if args.delete:
        confirm = input(f"  Delete '{DYNAMODB_TABLE}' and all its data? [yes/no]: ").strip()
        if confirm.lower() != "yes":
            print("  Aborted.")
            return
        delete_table(client, DYNAMODB_TABLE)

    create_table(client, DYNAMODB_TABLE)
    describe_table(client, DYNAMODB_TABLE)


if __name__ == "__main__":
    main()
