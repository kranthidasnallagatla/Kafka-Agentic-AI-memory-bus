"""
memory/memory_store.py — Phase 1 in-memory store (kept for local dev + tests)
Identical to Phase 1. Used when USE_LOCAL=true.
"""

import threading
from datetime import datetime
from typing import Any
from config.settings import get_logger

logger = get_logger("MemoryStore")


class MemoryStore:
    def __init__(self):
        self._store: dict = {}
        self._lock  = threading.RLock()

    def get(self, session_id: str) -> dict:
        with self._lock:
            return dict(self._store.get(session_id, {}))

    def update(self, session_id: str, key: str, value: Any) -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["context"][key] = value
            self._store[session_id]["last_updated"] = _now()

    def append_history(self, session_id: str, role: str, content: str) -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["history"].append(
                {"role": role, "content": content, "ts": _now()}
            )
            self._store[session_id]["last_updated"] = _now()

    def set_last_agent(self, session_id: str, agent_id: str) -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._store[session_id]["last_agent"]   = agent_id
            self._store[session_id]["last_updated"] = _now()

    def get_history(self, session_id: str) -> list:
        with self._lock:
            return list(self._store.get(session_id, {}).get("history", []))

    def get_context(self, session_id: str, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._store.get(session_id, {}).get("context", {}).get(key, default)

    def clear_session(self, session_id: str) -> None:
        with self._lock:
            self._store.pop(session_id, None)

    def all_sessions(self) -> list:
        with self._lock:
            return list(self._store.keys())

    def _ensure_session(self, session_id: str) -> None:
        if session_id not in self._store:
            self._store[session_id] = {
                "session_id": session_id,
                "history":    [],
                "context":    {},
                "last_agent": None,
                "last_updated": _now(),
                "created_at":   _now(),
            }


def _now() -> str:
    return datetime.utcnow().isoformat()
