"""
memory/dynamo_memory_store.py  —  Phase 2
──────────────────────────────────────────
Drop-in replacement for Phase 1's in-memory MemoryStore.
Backed by AWS DynamoDB — persistent, scalable, survives restarts.

DynamoDB table schema:
  PK: session_id (String)   ← partition key
  Attributes:
    history      (List)     ← full conversation turns
    context      (Map)      ← arbitrary key-value facts per session
    last_agent   (String)
    last_updated (String)   ← ISO timestamp
    created_at   (String)

The public API is identical to Phase 1's MemoryStore —
agents call the same methods, nothing in agent code changes.
"""

import json
from datetime import datetime
from typing import Any

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

from config.settings import AWS_REGION, DYNAMODB_TABLE, get_logger

logger = get_logger("DynamoMemoryStore")


class DynamoMemoryStore:
    """
    Persistent shared memory backed by DynamoDB.

    Each session is one DynamoDB item:
    {
        "session_id":   "uuid",
        "history":      [...],
        "context":      {...},
        "last_agent":   "BillingAgent",
        "last_updated": "2026-04-27T10:34:22",
        "created_at":   "2026-04-27T10:30:01",
    }
    """

    def __init__(self):
        self._dynamo = boto3.resource(
            "dynamodb",
            region_name=AWS_REGION,
        )
        self._table = self._dynamo.Table(DYNAMODB_TABLE)
        logger.info(f"DynamoMemoryStore connected — table: {DYNAMODB_TABLE} / region: {AWS_REGION}")

    # ── Public API (identical to Phase 1 MemoryStore) ──────────────────────

    def get(self, session_id: str) -> dict:
        """Return full session record, empty dict if not found."""
        try:
            resp = self._table.get_item(Key={"session_id": session_id})
            return resp.get("Item", {})
        except ClientError as e:
            logger.error(f"DynamoDB get failed [{session_id}]: {e}")
            return {}

    def update(self, session_id: str, key: str, value: Any) -> None:
        """Set an arbitrary key inside the session's context map."""
        self._ensure_session(session_id)
        try:
            self._table.update_item(
                Key={"session_id": session_id},
                UpdateExpression="SET #ctx.#k = :v, last_updated = :ts",
                ExpressionAttributeNames={"#ctx": "context", "#k": key},
                ExpressionAttributeValues={":v": value, ":ts": _now()},
            )
            logger.debug(f"[{session_id}] context.{key} = {value}")
        except ClientError as e:
            logger.error(f"DynamoDB update failed [{session_id}]: {e}")

    def append_history(self, session_id: str, role: str, content: str) -> None:
        """Append a conversation turn to the session history list."""
        self._ensure_session(session_id)
        entry = {"role": role, "content": content, "ts": _now()}
        try:
            self._table.update_item(
                Key={"session_id": session_id},
                UpdateExpression=(
                    "SET history = list_append(history, :entry), "
                    "last_updated = :ts"
                ),
                ExpressionAttributeValues={
                    ":entry": [entry],
                    ":ts":    _now(),
                },
            )
        except ClientError as e:
            logger.error(f"DynamoDB append_history failed [{session_id}]: {e}")

    def set_last_agent(self, session_id: str, agent_id: str) -> None:
        self._ensure_session(session_id)
        try:
            self._table.update_item(
                Key={"session_id": session_id},
                UpdateExpression="SET last_agent = :a, last_updated = :ts",
                ExpressionAttributeValues={":a": agent_id, ":ts": _now()},
            )
        except ClientError as e:
            logger.error(f"DynamoDB set_last_agent failed [{session_id}]: {e}")

    def get_history(self, session_id: str) -> list:
        record = self.get(session_id)
        return record.get("history", [])

    def get_context(self, session_id: str, key: str, default: Any = None) -> Any:
        record = self.get(session_id)
        return record.get("context", {}).get(key, default)

    def clear_session(self, session_id: str) -> None:
        try:
            self._table.delete_item(Key={"session_id": session_id})
            logger.info(f"[{session_id}] session deleted from DynamoDB")
        except ClientError as e:
            logger.error(f"DynamoDB clear_session failed [{session_id}]: {e}")

    def all_sessions(self) -> list[str]:
        """Scan all session IDs (use sparingly — full table scan)."""
        try:
            resp  = self._table.scan(ProjectionExpression="session_id")
            return [item["session_id"] for item in resp.get("Items", [])]
        except ClientError as e:
            logger.error(f"DynamoDB scan failed: {e}")
            return []

    # ── Private ────────────────────────────────────────────────────────────

    def _ensure_session(self, session_id: str) -> None:
        """
        Create a blank session item if one doesn't exist.
        Uses conditional write — safe to call concurrently.
        """
        try:
            self._table.put_item(
                Item={
                    "session_id":   session_id,
                    "history":      [],
                    "context":      {},
                    "last_agent":   None,
                    "last_updated": _now(),
                    "created_at":   _now(),
                },
                ConditionExpression="attribute_not_exists(session_id)",
            )
            logger.info(f"[{session_id}] new session created in DynamoDB")
        except ClientError as e:
            # ConditionalCheckFailedException = session already exists — fine
            if e.response["Error"]["Code"] != "ConditionalCheckFailedException":
                logger.error(f"DynamoDB _ensure_session failed [{session_id}]: {e}")


def _now() -> str:
    return datetime.utcnow().isoformat()
