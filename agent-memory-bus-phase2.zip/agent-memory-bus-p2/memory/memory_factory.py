"""
memory/memory_factory.py  —  Phase 2
──────────────────────────────────────
Returns the right memory backend based on USE_LOCAL env var.

  USE_LOCAL=true  → in-process dict  (no AWS needed, same as Phase 1)
  USE_LOCAL=false → DynamoDB          (production)

Every agent and the Orchestrator call get_memory_store() once at startup.
"""

from config.settings import USE_LOCAL, get_logger

logger = get_logger("MemoryFactory")


def get_memory_store():
    if USE_LOCAL:
        logger.info("Memory backend: in-memory (USE_LOCAL=true)")
        from memory.memory_store import MemoryStore
        return MemoryStore()
    else:
        logger.info("Memory backend: AWS DynamoDB")
        from memory.dynamo_memory_store import DynamoMemoryStore
        return DynamoMemoryStore()
