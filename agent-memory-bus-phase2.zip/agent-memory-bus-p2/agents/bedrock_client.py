"""
agents/bedrock_client.py  —  Phase 2
──────────────────────────────────────
Thin wrapper around boto3 bedrock-runtime.
All agents call invoke() — no agent needs to know the API shape.

Supports:
  - Claude 3 Sonnet (default)
  - Automatic retry on throttling (3 attempts)
  - Structured system + user prompt pattern
"""

import json
import time

import boto3
from botocore.exceptions import ClientError

from config.settings import AWS_REGION, BEDROCK_MODEL_ID, BEDROCK_MAX_TOKENS, get_logger

logger = get_logger("BedrockClient")


class BedrockClient:

    def __init__(self):
        self._client = boto3.client(
            "bedrock-runtime",
            region_name=AWS_REGION,
        )
        self._model_id = BEDROCK_MODEL_ID
        logger.info(f"BedrockClient ready — model: {self._model_id}")

    def invoke(
        self,
        user_prompt:   str,
        system_prompt: str = "",
        max_tokens:    int = BEDROCK_MAX_TOKENS,
        retries:       int = 3,
    ) -> str:
        """
        Call Bedrock and return the assistant's plain-text response.

        Args:
            user_prompt:   The user's message or the full constructed prompt.
            system_prompt: Optional system context that shapes the agent's persona.
            max_tokens:    Maximum tokens in the response.
            retries:       Retry count on throttling errors.

        Returns:
            Response string, or an error message if all retries fail.
        """
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens":        max_tokens,
            "messages": [
                {"role": "user", "content": user_prompt}
            ],
        }
        if system_prompt:
            body["system"] = system_prompt

        for attempt in range(1, retries + 1):
            try:
                response = self._client.invoke_model(
                    modelId=self._model_id,
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(body),
                )
                result = json.loads(response["body"].read())
                text   = result["content"][0]["text"].strip()
                logger.debug(f"Bedrock response ({len(text)} chars)")
                return text

            except ClientError as e:
                code = e.response["Error"]["Code"]
                if code == "ThrottlingException" and attempt < retries:
                    wait = 2 ** attempt          # exponential back-off
                    logger.warning(f"Throttled — retrying in {wait}s (attempt {attempt}/{retries})")
                    time.sleep(wait)
                else:
                    logger.error(f"Bedrock invoke failed: {e}")
                    return "I'm experiencing a temporary issue. Please try again in a moment."

        return "I'm currently unavailable. Please try again shortly."


# ── Singleton ──────────────────────────────────────────────────────────────
# Shared across all agents so we don't create a boto3 client per message.
_bedrock_client: BedrockClient | None = None

def get_bedrock_client() -> BedrockClient:
    global _bedrock_client
    if _bedrock_client is None:
        _bedrock_client = BedrockClient()
    return _bedrock_client
