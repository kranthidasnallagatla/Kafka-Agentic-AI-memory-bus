"""
agents/order_agent.py  —  Phase 2
───────────────────────────────────
Order management specialist powered by AWS Bedrock (Claude 3 Sonnet).

Reads the stable order_id from DynamoDB shared memory so the LLM
always has the right order context across multiple turns.
"""

import re
import random
import string

from agents.base_agent import BaseAgent
from agents.bedrock_client import get_bedrock_client

SYSTEM_PROMPT = """You are an Order Management Agent for an e-commerce company.
You specialise in order tracking, cancellations, returns, exchanges, refunds, and shipping.

Your rules:
- Always reference the customer's order ID when it is known.
- Be empathetic for delays or missing items.
- Provide specific next steps, not generic answers.
- Responses must be under 120 words.
- Do not mention that you are an AI.
"""


class OrderAgent(BaseAgent):

    def __init__(self, memory_store):
        super().__init__("OrderAgent", memory_store)
        self._bedrock = get_bedrock_client()

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "")

        # Retrieve or create stable order ID for this session
        order_id = self.get_context(session_id, "order_id")
        if not order_id:
            order_id = "ORD-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
            self.set_context(session_id, "order_id", order_id)

        history = self.get_history(session_id)
        prompt  = _build_prompt(text, history, order_id)

        self.logger.info(f"[{session_id}] → Bedrock (order, order_id={order_id})")
        return self._bedrock.invoke(prompt, system_prompt=SYSTEM_PROMPT)


def _build_prompt(current_text: str, history: list, order_id: str) -> str:
    lines = [f"Customer's order ID for this session: {order_id}"]

    if history:
        lines.append("Prior conversation context:")
        for turn in history[-6:]:
            role = "Customer" if turn["role"] == "user" else "Agent"
            lines.append(f"  {role}: {turn['content']}")

    lines.append(f"\nNew customer message: {current_text}")
    lines.append("Always reference the order ID above in your response.")
    return "\n".join(lines)
