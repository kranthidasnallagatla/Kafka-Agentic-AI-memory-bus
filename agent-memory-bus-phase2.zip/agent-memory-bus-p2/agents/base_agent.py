"""
agents/base_agent.py  —  Phase 2
──────────────────────────────────
Identical public API to Phase 1.
Only change: Kafka producer now supports TLS for AWS MSK.
"""

import json
from abc import ABC, abstractmethod
from datetime import datetime

from kafka import KafkaProducer
from kafka.errors import KafkaError

from config.settings import KAFKA_BROKER, KAFKA_USE_TLS, TOPICS, get_logger


class BaseAgent(ABC):

    def __init__(self, agent_id: str, memory_store):
        self.agent_id  = agent_id
        self.memory    = memory_store
        self.logger    = get_logger(agent_id)
        self._producer = self._build_producer()

    @abstractmethod
    def handle(self, message: dict) -> str:
        """Process message and return response text."""

    def process(self, message: dict) -> None:
        session_id = message["session_id"]
        user_id    = message["user_id"]
        text       = message.get("text", "")

        self.memory.append_history(session_id, "user", text)
        self.memory.set_last_agent(session_id, self.agent_id)

        response_text = self.handle(message)

        self.memory.append_history(session_id, "assistant", response_text)
        self._publish_response(session_id, user_id, response_text)
        self._publish_audit(session_id, "RESPONSE_GENERATED", {
            "user_text": text,
            "response":  response_text,
        })
        self.logger.info(f"[{session_id}] handled and published ✓")

    # ── Memory helpers ─────────────────────────────────────────────────────
    def get_history(self, session_id: str) -> list:
        return self.memory.get_history(session_id)

    def get_context(self, session_id: str, key: str, default=None):
        return self.memory.get_context(session_id, key, default)

    def set_context(self, session_id: str, key: str, value) -> None:
        self.memory.update(session_id, key, value)

    # ── Private ────────────────────────────────────────────────────────────
    def _publish_response(self, session_id: str, user_id: str, text: str) -> None:
        self._safe_send(TOPICS["response"], session_id, {
            "session_id": session_id, "user_id": user_id,
            "agent_id":   self.agent_id, "response": text,
            "timestamp":  _now(),
        })

    def _publish_audit(self, session_id: str, event_type: str, payload: dict) -> None:
        self._safe_send(TOPICS["audit"], session_id, {
            "session_id": session_id, "agent_id": self.agent_id,
            "event_type": event_type, "payload":  payload,
            "timestamp":  _now(),
        })

    def _safe_send(self, topic: str, key: str, value: dict) -> None:
        try:
            future = self._producer.send(
                topic,
                key=key.encode("utf-8"),
                value=json.dumps(value).encode("utf-8"),
            )
            self._producer.flush()
            future.get(timeout=10)
        except KafkaError as e:
            self.logger.error(f"Kafka send failed [{topic}]: {e}")

    def _build_producer(self) -> KafkaProducer:
        kwargs = dict(
            bootstrap_servers=KAFKA_BROKER,
            retries=5,
            acks="all",
            linger_ms=5,
        )
        # TLS for AWS MSK
        if KAFKA_USE_TLS:
            kwargs.update(
                security_protocol="SSL",
                ssl_check_hostname=True,
            )
        return KafkaProducer(**kwargs)


def _now() -> str:
    return datetime.utcnow().isoformat()
