"""
agents/billing_agent.py  —  Phase 2
──────────────────────────────────────
Billing specialist powered by AWS Bedrock (Claude 3 Sonnet).

Each request:
  1. Loads full conversation history from DynamoDB
  2. Builds a structured prompt with that history + system persona
  3. Calls Bedrock and returns the LLM response
  4. BaseAgent persists the response and publishes to Kafka
"""

from agents.base_agent import BaseAgent
from agents.bedrock_client import get_bedrock_client

SYSTEM_PROMPT = """You are a Billing Support Agent for a SaaS company.
You specialise in invoices, charges, refunds, subscriptions, payment methods, and account credits.

Your rules:
- Be concise, professional, and empathetic.
- Never make up account-specific data — if you need details, ask for them.
- If the customer has contacted billing before (history shows prior turns), acknowledge that and build on it.
- Responses must be under 120 words.
- Do not mention that you are an AI.
"""


class BillingAgent(BaseAgent):

    def __init__(self, memory_store):
        super().__init__("BillingAgent", memory_store)
        self._bedrock = get_bedrock_client()

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "")

        # Build conversation-aware prompt
        history = self.get_history(session_id)
        prompt  = _build_prompt(text, history)

        # Track visit count in shared memory
        visits = self.get_context(session_id, "billing_visits", 0) + 1
        self.set_context(session_id, "billing_visits", visits)

        self.logger.info(f"[{session_id}] → Bedrock (billing, visit #{visits})")
        return self._bedrock.invoke(prompt, system_prompt=SYSTEM_PROMPT)


def _build_prompt(current_text: str, history: list) -> str:
    """
    Inject prior conversation turns into the prompt so Bedrock
    has full context about what the customer has already said.
    """
    if not history:
        return current_text

    lines = ["Prior conversation context:"]
    # Include last 6 turns maximum to stay within token budget
    for turn in history[-6:]:
        role    = "Customer" if turn["role"] == "user" else "Agent"
        lines.append(f"  {role}: {turn['content']}")

    lines.append(f"\nNew customer message: {current_text}")
    lines.append("\nRespond to the new message, taking the prior context into account.")
    return "\n".join(lines)
