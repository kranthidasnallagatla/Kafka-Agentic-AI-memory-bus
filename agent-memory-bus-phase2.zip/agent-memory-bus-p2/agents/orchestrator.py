"""
agents/orchestrator.py  —  Phase 2
────────────────────────────────────
Orchestrator with Bedrock-powered intent classification.

Phase 1: keyword voting (fast, no LLM cost)
Phase 2: Bedrock zero-shot classifier — more accurate on ambiguous messages
         Falls back to keyword voting if Bedrock call fails.

All routing, audit, and memory logic is unchanged from Phase 1.
"""

import json
import signal

from kafka import KafkaConsumer
from kafka.errors import KafkaError

from config.settings import (
    KAFKA_BROKER, KAFKA_GROUP_ID, KAFKA_USE_TLS,
    TOPICS, get_logger,
)
from memory.memory_factory import get_memory_store
from agents.billing_agent import BillingAgent
from agents.tech_agent import TechAgent
from agents.order_agent import OrderAgent
from agents.bedrock_client import get_bedrock_client

logger = get_logger("Orchestrator")

# ── Keyword fallback (used when Bedrock classification fails) ──────────────
INTENT_KEYWORDS = {
    "billing": ["invoice","charge","refund","subscription","payment","billing","discount","overcharge","fee","receipt"],
    "tech":    ["error","crash","slow","login","password","install","bug","update","api","connectivity","setup","broken"],
    "order":   ["order","track","cancel","return","shipping","delay","deliver","exchange","missing","package","parcel"],
}

# ── Bedrock zero-shot classification prompt ────────────────────────────────
CLASSIFY_SYSTEM = (
    "You are an intent classifier for a customer support system. "
    "Classify the user message into exactly one of: billing, tech, order. "
    "Return ONLY the single word. Nothing else."
)


class Orchestrator:

    def __init__(self):
        self.memory   = get_memory_store()
        self.agents   = {
            "billing": BillingAgent(self.memory),
            "tech":    TechAgent(self.memory),
            "order":   OrderAgent(self.memory),
        }
        self.bedrock  = get_bedrock_client()
        self.consumer = self._build_consumer()
        self._running = False
        logger.info("Orchestrator ready — agents: billing, tech, order | classifier: Bedrock")

    # ── Main loop ──────────────────────────────────────────────────────────

    def run(self) -> None:
        self._running = True
        self._register_shutdown()
        logger.info(f"Listening on topic: {TOPICS['input']} ...")

        try:
            for kafka_message in self.consumer:
                if not self._running:
                    break
                self._handle_kafka_message(kafka_message)
        except Exception as e:
            logger.error(f"Consumer loop error: {e}")
        finally:
            self.consumer.close()
            logger.info("Orchestrator shut down cleanly.")

    # ── Internal ───────────────────────────────────────────────────────────

    def _handle_kafka_message(self, kafka_message) -> None:
        try:
            msg = json.loads(kafka_message.value.decode("utf-8"))
        except (json.JSONDecodeError, AttributeError) as e:
            logger.error(f"Failed to decode message: {e}")
            return

        session_id = msg.get("session_id")
        text       = msg.get("text", "")

        if not session_id or not text:
            logger.warning("Message missing session_id or text — skipping.")
            return

        logger.info(f"[{session_id}] ← \"{text[:70]}\"")

        intent = self._classify_intent(text)
        logger.info(f"[{session_id}] intent → {intent}")

        agent = self.agents.get(intent)
        if not agent:
            logger.error(f"No agent for intent: {intent}")
            return

        agent.process(msg)

    def _classify_intent(self, text: str) -> str:
        """
        Phase 2: Bedrock zero-shot classifier.
        Falls back to keyword voting on failure.
        """
        try:
            result = self.bedrock.invoke(
                user_prompt=f"Customer message: {text}",
                system_prompt=CLASSIFY_SYSTEM,
                max_tokens=5,
            ).strip().lower()

            if result in self.agents:
                logger.debug(f"Bedrock classified → {result}")
                return result
            else:
                logger.warning(f"Bedrock returned unexpected label '{result}' — using keyword fallback")
        except Exception as e:
            logger.warning(f"Bedrock classification failed: {e} — using keyword fallback")

        return self._keyword_classify(text)

    def _keyword_classify(self, text: str) -> str:
        """Keyword voting fallback — same as Phase 1."""
        text_lower = text.lower()
        scores     = {intent: 0 for intent in INTENT_KEYWORDS}
        for intent, keywords in INTENT_KEYWORDS.items():
            for kw in keywords:
                if kw in text_lower:
                    scores[intent] += 1
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 else "tech"

    def _build_consumer(self) -> KafkaConsumer:
        kwargs = dict(
            bootstrap_servers=KAFKA_BROKER,
            group_id=KAFKA_GROUP_ID,
            auto_offset_reset="latest",
            enable_auto_commit=True,
            value_deserializer=None,
        )
        if KAFKA_USE_TLS:
            kwargs.update(security_protocol="SSL", ssl_check_hostname=True)
        return KafkaConsumer(TOPICS["input"], **kwargs)

    def _register_shutdown(self) -> None:
        def _handler(sig, frame):
            logger.info("Shutdown signal received.")
            self._running = False
        signal.signal(signal.SIGINT, _handler)
        signal.signal(signal.SIGTERM, _handler)


if __name__ == "__main__":
    Orchestrator().run()
