"""
agents/tech_agent.py  —  Phase 2
──────────────────────────────────
Tech Support specialist powered by AWS Bedrock (Claude 3 Sonnet).

Reads open ticket list from shared memory (DynamoDB) and injects it
into every Bedrock prompt — so the LLM knows what has already been
reported in this session without the user repeating themselves.
"""

from agents.base_agent import BaseAgent
from agents.bedrock_client import get_bedrock_client

SYSTEM_PROMPT = """You are a Tier 1 Technical Support Agent for a SaaS company.
You specialise in software errors, crashes, login issues, bugs, API problems, and installation help.

Your rules:
- Be clear, methodical, and calm.
- If a bug is new, generate a ticket ID in format TKT-XXXX (use a random 4-digit number).
- If prior tickets are mentioned in context, reference them by ID.
- Provide actionable troubleshooting steps, not vague answers.
- Responses must be under 130 words.
- Do not mention that you are an AI.
"""


class TechAgent(BaseAgent):

    def __init__(self, memory_store):
        super().__init__("TechAgent", memory_store)
        self._bedrock = get_bedrock_client()

    def handle(self, message: dict) -> str:
        session_id = message["session_id"]
        text       = message.get("text", "")

        # Load shared memory context
        history      = self.get_history(session_id)
        open_tickets = self.get_context(session_id, "open_tickets", [])

        prompt   = _build_prompt(text, history, open_tickets)
        response = self._bedrock.invoke(prompt, system_prompt=SYSTEM_PROMPT)

        # Extract any new ticket IDs from the LLM response and persist them
        import re
        new_tickets = re.findall(r"TKT-\d{4}", response)
        if new_tickets:
            updated = list(set(open_tickets + new_tickets))
            self.set_context(session_id, "open_tickets", updated)
            self.logger.info(f"[{session_id}] tickets updated → {updated}")

        return response


def _build_prompt(current_text: str, history: list, open_tickets: list) -> str:
    lines = []

    if open_tickets:
        lines.append(f"Open tickets in this session: {', '.join(open_tickets)}")

    if history:
        lines.append("Prior conversation context:")
        for turn in history[-6:]:
            role = "Customer" if turn["role"] == "user" else "Agent"
            lines.append(f"  {role}: {turn['content']}")

    lines.append(f"\nNew customer message: {current_text}")
    if open_tickets:
        lines.append("Reference existing ticket IDs where relevant. Only create a new ticket for a genuinely new issue.")

    return "\n".join(lines) if lines else current_text
