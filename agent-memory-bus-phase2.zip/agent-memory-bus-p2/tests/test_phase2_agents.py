"""
tests/test_phase2_agents.py  —  Phase 2
─────────────────────────────────────────
Unit tests for Phase 2 agents.
Both Bedrock and DynamoDB are mocked — no AWS needed.

Run:  python tests/test_phase2_agents.py
"""

import sys
import uuid
from unittest.mock import MagicMock, patch
sys.path.insert(0, ".")

from memory.memory_store import MemoryStore   # use in-memory for tests


def make_agent(AgentClass):
    memory = MemoryStore()
    with patch("agents.base_agent.KafkaProducer") as MockKafka, \
         patch("agents.bedrock_client.boto3") as MockBoto:

        # Mock Kafka
        mk = MagicMock()
        mf = MagicMock(); mf.get.return_value = MagicMock()
        mk.send.return_value = mf
        MockKafka.return_value = mk

        # Mock Bedrock
        mock_client = MagicMock()
        mock_body   = MagicMock()
        import json
        mock_body.read.return_value = json.dumps({
            "content": [{"text": "Mocked Bedrock response for testing."}]
        }).encode()
        mock_client.invoke_model.return_value = {"body": mock_body}
        MockBoto.client.return_value = mock_client

        agent = AgentClass(memory)
        agent._producer = mk

        # Replace bedrock client with a pre-built mock
        from agents.bedrock_client import BedrockClient
        mock_bedrock = MagicMock(spec=BedrockClient)
        mock_bedrock.invoke.return_value = "Mocked Bedrock response for testing."
        agent._bedrock = mock_bedrock

    return agent, memory, mock_bedrock


def msg(text, session_id=None):
    return {"session_id": session_id or str(uuid.uuid4()), "user_id": "test", "text": text}


# ── BillingAgent ─────────────────────────────────────────────────────────

def test_billing_calls_bedrock():
    from agents.billing_agent import BillingAgent
    agent, _, bedrock = make_agent(BillingAgent)
    agent.handle(msg("I need a refund"))
    assert bedrock.invoke.called
    print("✅  test_billing_calls_bedrock")


def test_billing_passes_system_prompt():
    from agents.billing_agent import BillingAgent
    agent, _, bedrock = make_agent(BillingAgent)
    agent.handle(msg("invoice issue"))
    call_kwargs = bedrock.invoke.call_args[1]
    assert "system_prompt" in call_kwargs
    assert "Billing" in call_kwargs["system_prompt"]
    print("✅  test_billing_passes_system_prompt")


def test_billing_history_injected_in_prompt():
    from agents.billing_agent import BillingAgent
    agent, memory, bedrock = make_agent(BillingAgent)
    sid = str(uuid.uuid4())
    memory.append_history(sid, "user", "I was overcharged last month")
    memory.append_history(sid, "assistant", "I see your concern, let me look into it")
    agent.handle(msg("still waiting for refund", sid))
    prompt = bedrock.invoke.call_args[0][0]
    assert "overcharged" in prompt
    print("✅  test_billing_history_injected_in_prompt")


def test_billing_visit_counter_increments():
    from agents.billing_agent import BillingAgent
    agent, memory, _ = make_agent(BillingAgent)
    sid = str(uuid.uuid4())
    agent.handle(msg("billing issue", sid))
    agent.handle(msg("billing issue again", sid))
    assert memory.get_context(sid, "billing_visits") == 2
    print("✅  test_billing_visit_counter_increments")


# ── TechAgent ─────────────────────────────────────────────────────────────

def test_tech_calls_bedrock():
    from agents.tech_agent import TechAgent
    agent, _, bedrock = make_agent(TechAgent)
    agent.handle(msg("app keeps crashing"))
    assert bedrock.invoke.called
    print("✅  test_tech_calls_bedrock")


def test_tech_open_tickets_in_prompt():
    from agents.tech_agent import TechAgent
    agent, memory, bedrock = make_agent(TechAgent)
    sid = str(uuid.uuid4())
    memory.update(sid, "open_tickets", ["TKT-1001"])
    agent.handle(msg("still broken", sid))
    prompt = bedrock.invoke.call_args[0][0]
    assert "TKT-1001" in prompt
    print("✅  test_tech_open_tickets_in_prompt")


def test_tech_extracts_ticket_ids_from_response():
    from agents.tech_agent import TechAgent
    agent, memory, bedrock = make_agent(TechAgent)
    bedrock.invoke.return_value = "I've created ticket TKT-9999 for your issue."
    sid = str(uuid.uuid4())
    agent.handle(msg("new bug", sid))
    tickets = memory.get_context(sid, "open_tickets", [])
    assert "TKT-9999" in tickets
    print("✅  test_tech_extracts_ticket_ids_from_response")


def test_tech_system_prompt_contains_persona():
    from agents.tech_agent import TechAgent
    agent, _, bedrock = make_agent(TechAgent)
    agent.handle(msg("login error"))
    call_kwargs = bedrock.invoke.call_args[1]
    assert "Technical Support" in call_kwargs["system_prompt"]
    print("✅  test_tech_system_prompt_contains_persona")


# ── OrderAgent ────────────────────────────────────────────────────────────

def test_order_calls_bedrock():
    from agents.order_agent import OrderAgent
    agent, _, bedrock = make_agent(OrderAgent)
    agent.handle(msg("where is my order"))
    assert bedrock.invoke.called
    print("✅  test_order_calls_bedrock")


def test_order_generates_stable_order_id():
    from agents.order_agent import OrderAgent
    agent, memory, _ = make_agent(OrderAgent)
    sid = str(uuid.uuid4())
    agent.handle(msg("track order", sid))
    id1 = memory.get_context(sid, "order_id")
    agent.handle(msg("cancel order", sid))
    id2 = memory.get_context(sid, "order_id")
    assert id1 == id2 and id1.startswith("ORD-")
    print("✅  test_order_generates_stable_order_id")


def test_order_id_injected_in_prompt():
    from agents.order_agent import OrderAgent
    agent, memory, bedrock = make_agent(OrderAgent)
    sid = str(uuid.uuid4())
    memory.update(sid, "order_id", "ORD-TESTID99")
    agent.handle(msg("return item", sid))
    prompt = bedrock.invoke.call_args[0][0]
    assert "ORD-TESTID99" in prompt
    print("✅  test_order_id_injected_in_prompt")


# ── Orchestrator intent classifier ────────────────────────────────────────

def test_orchestrator_bedrock_classify():
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"), \
         patch("agents.bedrock_client.boto3"), \
         patch("memory.memory_factory.get_memory_store") as mock_mem:

        mock_mem.return_value = MemoryStore()
        from agents.orchestrator import Orchestrator
        orch = Orchestrator()

        orch.bedrock = MagicMock()
        orch.bedrock.invoke.return_value = "billing"
        result = orch._classify_intent("I need a refund")
        assert result == "billing"
    print("✅  test_orchestrator_bedrock_classify")


def test_orchestrator_falls_back_to_keywords():
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"), \
         patch("agents.bedrock_client.boto3"), \
         patch("memory.memory_factory.get_memory_store") as mock_mem:

        mock_mem.return_value = MemoryStore()
        from agents.orchestrator import Orchestrator
        orch = Orchestrator()

        # Make Bedrock fail
        orch.bedrock = MagicMock()
        orch.bedrock.invoke.side_effect = Exception("Bedrock unavailable")
        result = orch._classify_intent("my invoice has a wrong charge")
        assert result == "billing"
    print("✅  test_orchestrator_falls_back_to_keywords")


def test_orchestrator_bad_bedrock_label_uses_fallback():
    with patch("agents.orchestrator.KafkaConsumer"), \
         patch("agents.base_agent.KafkaProducer"), \
         patch("agents.bedrock_client.boto3"), \
         patch("memory.memory_factory.get_memory_store") as mock_mem:

        mock_mem.return_value = MemoryStore()
        from agents.orchestrator import Orchestrator
        orch = Orchestrator()

        orch.bedrock = MagicMock()
        orch.bedrock.invoke.return_value = "unknown_label"  # bad response
        result = orch._classify_intent("app keeps crashing")
        assert result in ("billing", "tech", "order")
    print("✅  test_orchestrator_bad_bedrock_label_uses_fallback")


# ── Shared memory across Phase 2 agents ───────────────────────────────────

def test_shared_memory_persists_across_agent_calls():
    from agents.billing_agent import BillingAgent
    from agents.order_agent   import OrderAgent
    memory = MemoryStore()

    with patch("agents.base_agent.KafkaProducer"), \
         patch("agents.bedrock_client.boto3"):
        billing = BillingAgent(memory)
        order   = OrderAgent(memory)
        billing._bedrock = MagicMock(); billing._bedrock.invoke.return_value = "ok"
        order._bedrock   = MagicMock(); order._bedrock.invoke.return_value   = "ok"

    sid = str(uuid.uuid4())
    billing.set_context(sid, "vip", True)
    val = order.get_context(sid, "vip")
    assert val is True
    print("✅  test_shared_memory_persists_across_agent_calls")


# ── Runner ─────────────────────────────────────────────────────────────────

ALL_TESTS = [
    test_billing_calls_bedrock,
    test_billing_passes_system_prompt,
    test_billing_history_injected_in_prompt,
    test_billing_visit_counter_increments,
    test_tech_calls_bedrock,
    test_tech_open_tickets_in_prompt,
    test_tech_extracts_ticket_ids_from_response,
    test_tech_system_prompt_contains_persona,
    test_order_calls_bedrock,
    test_order_generates_stable_order_id,
    test_order_id_injected_in_prompt,
    test_orchestrator_bedrock_classify,
    test_orchestrator_falls_back_to_keywords,
    test_orchestrator_bad_bedrock_label_uses_fallback,
    test_shared_memory_persists_across_agent_calls,
]

if __name__ == "__main__":
    print("\n  Running Phase 2 Agent tests ...\n")
    passed = 0
    for test in ALL_TESTS:
        test()
        passed += 1
    print(f"\n  {passed}/{len(ALL_TESTS)} tests passed ✅\n")
