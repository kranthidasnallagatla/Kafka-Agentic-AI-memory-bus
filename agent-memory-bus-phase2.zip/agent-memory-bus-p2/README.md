# Agent Memory Bus — Phase 2

Extends Phase 1 with three AWS upgrades:

| Component | Phase 1 | Phase 2 |
|-----------|---------|---------|
| Agent responses | Keyword matching | AWS Bedrock (Claude 3 Sonnet) |
| Shared memory | In-process dict | AWS DynamoDB |
| Kafka broker | Docker (local) | AWS MSK |

---

## Prerequisites

- AWS account with access to Bedrock, DynamoDB, and MSK
- Bedrock model access enabled for `anthropic.claude-3-sonnet-20240229-v1:0`
- Python 3.9+
- AWS CLI configured (`aws configure`)

---

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# Edit .env — fill in AWS credentials + MSK broker URL

# 3. Full setup (DynamoDB + MSK topics)
bash scripts/setup_phase2.sh
```

---

## Running

```bash
# Terminal 1
python agents/orchestrator.py

# Terminal 2
python consumers/response_consumer.py

# Terminal 3
python producers/input_producer.py --demo
```

---

## Local Development (no AWS)

Set `USE_LOCAL=true` in `.env` to run with local Kafka + in-memory store:

```bash
USE_LOCAL=true
KAFKA_BROKER=localhost:9092
```

Then start local Kafka from Phase 1's docker directory.

---

## Tests

All tests mock Bedrock and DynamoDB — no AWS credentials needed.

```bash
python tests/test_phase2_agents.py
```

---

## What Changed from Phase 1

### agents/billing_agent.py
- `_generate_response()` keyword logic → `bedrock.invoke()` with system prompt
- Conversation history injected into every Bedrock prompt

### agents/tech_agent.py
- Keyword matching → Bedrock LLM
- Response scanned for `TKT-XXXX` patterns, persisted to DynamoDB

### agents/order_agent.py
- Keyword matching → Bedrock LLM
- Order ID from DynamoDB injected into every prompt

### agents/orchestrator.py
- Keyword voting → Bedrock zero-shot classifier
- Automatic fallback to keywords if Bedrock call fails

### memory/
- `dynamo_memory_store.py` — new DynamoDB backend
- `memory_factory.py` — switches backend based on `USE_LOCAL`

### config/settings.py
- Added `KAFKA_USE_TLS`, `BEDROCK_MAX_TOKENS`, `USE_LOCAL`

---

## Roadmap

| Phase | Status | Description |
|-------|--------|-------------|
| 1 | ✅ Complete | Local Kafka, keyword agents, in-memory store |
| 2 | ✅ Complete | Bedrock LLM agents, DynamoDB, AWS MSK |
| 3 | 🔜 Planned  | API Gateway, Transcribe (voice), multi-client |
| 4 | 🔜 Planned  | CloudWatch, SNS alerts, S3 audit archive |
